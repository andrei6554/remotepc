"""
Remote Control PC - AGENT (programul mic de pe PC-ul tau).

Il pornesti o data pe PC. Iti afiseaza un COD si o PAROLA.
Intri pe site, scrii codul + parola, si controlezi PC-ul de oriunde.
Nu are nevoie de IP, port forwarding sau ngrok.

Configurare server: pune linkul site-ului in agent_config.json -> "server"
(implicit foloseste linkul de preview Emergent).
"""
import os
import sys
import json
import time
import hmac
import base64
import asyncio
import platform
import subprocess
from datetime import datetime


import websockets

try:
    import psutil
except Exception:
    psutil = None

IS_WINDOWS = platform.system() == "Windows"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "agent_config.json")

# linkul serverului central (schimba-l cu domeniul tau dupa deploy)
DEFAULT_SERVER = "https://d14e095e-56c9-4726-99d4-70b3cd60162a.preview.emergentagent.com"


def get_local_ip():
    """Returneaza IPv4-ul local al acestui PC."""
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def load_config():
    local_ip = get_local_ip()
    cfg = {"code": local_ip,
           "name": platform.node() or "PC-ul meu",
           "server": DEFAULT_SERVER}
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                saved = json.load(f)
                cfg.update(saved)
        except Exception:
            pass
    # Actualizeaza mereu IP-ul (se poate schimba)
    cfg["code"] = local_ip
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    return cfg


CONFIG = load_config()
SIM_VOLUME = 42
_CPU = {"val": None}


# --------------------------------------------------------------- OS actions
def run_cmd(cmd, shell=True):
    if not IS_WINDOWS:
        return True, "simulat (ruleaza pe Windows pentru efect real)"
    try:
        subprocess.Popen(cmd, shell=shell)
        return True, "comanda trimisa"
    except Exception as e:
        return False, str(e)


def run_ps(ps):
    if not IS_WINDOWS:
        return True, "simulat (ruleaza pe Windows pentru efect real)"
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-Command", ps], shell=False)
        return True, "comanda trimisa"
    except Exception as e:
        return False, str(e)


def vol_key(code, repeat):
    if not IS_WINDOWS:
        return True, "simulat"
    ps = "$o=New-Object -ComObject WScript.Shell;" + \
        ";".join(["$o.SendKeys([char]%d)" % code for _ in range(repeat)])
    return run_ps(ps)


MONITOR_OFF = ("$t=Add-Type -MemberDefinition '[DllImport(\"user32.dll\")] public "
               "static extern int SendMessage(int hWnd,int hMsg,int wParam,int lParam);' "
               "-Name W -Namespace N -PassThru;$t::SendMessage(0xffff,0x0112,0xF170,2)")


def _endpoint_volume():
    from ctypes import cast, POINTER
    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
    spk = AudioUtilities.GetSpeakers()
    if not hasattr(spk, "Activate"):
        spk = getattr(spk, "_dev", None) or spk
    iface = spk.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    return cast(iface, POINTER(IAudioEndpointVolume))


def get_volume():
    if not IS_WINDOWS:
        return SIM_VOLUME
    try:
        return int(round(_endpoint_volume().GetMasterVolumeLevelScalar() * 100))
    except Exception:
        return None


def set_volume(pct):
    global SIM_VOLUME
    pct = max(0, min(100, int(pct)))
    if not IS_WINDOWS:
        SIM_VOLUME = pct
        return True, "Volum %d%% (simulat)" % pct
    try:
        _endpoint_volume().SetMasterVolumeLevelScalar(pct / 100.0, None)
        return True, "Volum setat la %d%%" % pct
    except Exception as e:
        return False, str(e)


def take_screenshot_b64():
    try:
        if IS_WINDOWS:
            from PIL import ImageGrab
            img = ImageGrab.grab()
        else:
            from PIL import Image, ImageDraw
            img = Image.new("RGB", (640, 360), (12, 12, 12))
            d = ImageDraw.Draw(img)
            d.text((20, 20), "Screenshot simulat - ruleaza pe Windows", fill=(255, 138, 0))
        import io
        b = io.BytesIO()
        img.save(b, "PNG")
        return base64.b64encode(b.getvalue()).decode()
    except Exception:
        return None


def get_now_playing():
    global _COVER
    if not IS_WINDOWS:
        dur = 210
        return {"title": "Demo Song (simulat)", "artist": "Spotify",
                "position": int(time.time()) % dur, "duration": dur, "cover": False}
    try:
        try:
            from winsdk.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as M
            from winsdk.windows.storage.streams import DataReader
        except Exception:
            from winrt.windows.media.control import GlobalSystemMediaTransportControlsSessionManager as M
            from winrt.windows.storage.streams import DataReader

        async def _g():
            mgr = await M.request_async()
            s = mgr.get_current_session()
            if not s:
                return None
            info = await s.try_get_media_properties_async()
            title = (info.title or "").strip()
            if not title:
                return None
            pos = dur = 0
            try:
                tl = s.get_timeline_properties()
                pos = int(tl.position.total_seconds()) if tl.position else 0
                dur = int(tl.end_time.total_seconds()) if tl.end_time else 0
            except Exception:
                pass
            cover_b64 = None
            try:
                if info.thumbnail:
                    stream = await info.thumbnail.open_read_async()
                    size = stream.size
                    if size:
                        r = DataReader(stream)
                        await r.load_async(size)
                        buf = bytearray(size)
                        r.read_bytes(buf)
                        cover_b64 = base64.b64encode(bytes(buf)).decode()
            except Exception:
                pass
            return {"title": title, "artist": (info.artist or "").strip(),
                    "position": pos, "duration": dur, "cover": cover_b64 is not None,
                    "_cover_b64": cover_b64}
        return asyncio.run(_g())
    except Exception:
        return None


APPS = {
    "chrome": "start chrome", "edge": "start msedge", "notepad": "notepad",
    "calc": "calc", "explorer": "explorer", "spotify": "start \"\" spotify:",
    "cmd": "start cmd", "settings": "start ms-settings:",
}

ACTIONS = {
    "shutdown": lambda: run_cmd("shutdown /s /t 3"),
    "restart": lambda: run_cmd("shutdown /r /t 3"),
    "abort": lambda: run_cmd("shutdown /a"),
    "sleep": lambda: run_cmd("rundll32.exe powrprof.dll,SetSuspendState 0,1,0"),
    "lock": lambda: run_cmd("rundll32.exe user32.dll,LockWorkStation"),
    "logoff": lambda: run_cmd("shutdown /l"),
    "monitor_off": lambda: run_ps(MONITOR_OFF),
    "mute": lambda: vol_key(173, 1),
    "vol_up": lambda: vol_key(175, 5),
    "vol_down": lambda: vol_key(174, 5),
    "media_play": lambda: vol_key(179, 1),
    "media_next": lambda: vol_key(176, 1),
    "media_prev": lambda: vol_key(177, 1),
    "taskmgr": lambda: run_cmd("taskmgr"),
}


# --------------------------------------------------------------- networking
def cpu_sampler():
    import threading

    def loop():
        while True:
            try:
                _CPU["val"] = psutil.cpu_percent(interval=1.0)
            except Exception:
                time.sleep(1)
    if psutil:
        threading.Thread(target=loop, daemon=True).start()


async def handle_command(ws, msg):
    action = msg.get("action")
    rid = msg.get("id")
    if action == "set_volume":
        ok, message = set_volume(msg.get("value") or 0)
    elif action == "screenshot":
        b64 = take_screenshot_b64()
        if b64:
            await ws.send(json.dumps({"type": "screenshot", "b64": b64}))
            ok, message = True, "screenshot trimis"
        else:
            ok, message = False, "eroare screenshot"
    elif action.startswith("open:"):
        app_id = action.split(":", 1)[1]
        cmd = APPS.get(app_id)
        ok, message = run_cmd(cmd) if cmd else (False, "aplicatie necunoscuta")
    elif action == "open_all":
        n = 0
        for c in APPS.values():
            o, _ = run_cmd(c)
            n += 1 if o else 0
            time.sleep(0.05)
        ok, message = True, "Am deschis %d aplicatii" % n
    elif action in ACTIONS:
        ok, message = ACTIONS[action]()
    else:
        ok, message = False, "actiune necunoscuta"
    await ws.send(json.dumps({"type": "result", "id": rid, "ok": ok, "message": message}))


async def status_loop(ws):
    last_cover_key = None
    while True:
        try:
            np = get_now_playing()
            data = {"cpu": (round(_CPU["val"]) if _CPU["val"] is not None else None),
                    "ram": (round(psutil.virtual_memory().percent) if psutil else None),
                    "volume": get_volume(),
                    "now_playing": ({k: v for k, v in np.items() if not k.startswith("_")} if np else None)}
            await ws.send(json.dumps({"type": "status", "data": data}))
            if np and np.get("_cover_b64"):
                key = np.get("title", "") + np.get("artist", "")
                if key != last_cover_key:
                    last_cover_key = key
                    await ws.send(json.dumps({"type": "cover", "b64": np["_cover_b64"], "mime": "image/jpeg"}))
            await asyncio.sleep(2)
        except Exception:
            return


async def run_agent():
    server = CONFIG["server"].replace("https://", "wss://").replace("http://", "ws://")
    ws_url = server.rstrip("/") + "/api/ws/agent"
    while True:
        try:
            async with websockets.connect(ws_url, max_size=8 * 1024 * 1024) as ws:
                await ws.send(json.dumps({"type": "register", "code": CONFIG["code"],
                                          "name": CONFIG["name"],
                                          "platform": platform.system()}))
                print("  [conectat la server - astept comenzi]")
                stask = asyncio.create_task(status_loop(ws))
                try:
                    async for raw in ws:
                        msg = json.loads(raw)
                        if msg.get("type") == "command":
                            asyncio.create_task(handle_command(ws, msg))
                finally:
                    stask.cancel()
        except Exception as e:
            print("  [deconectat: %s] reconectare in 5s..." % e)
            await asyncio.sleep(5)


def main():
    cpu_sampler()
    print("=" * 56)
    print("   REMOTE CONTROL PC - AGENT")
    print("=" * 56)
    print("   Intra pe site si introdu IPv4-ul tau:")
    print("")
    print("     IPv4:  %s" % CONFIG["code"])
    print("")
    print("   Site: %s" % CONFIG["server"])
    print("   (IPv4-ul se actualizeaza automat la fiecare pornire)")
    print("=" * 56)
    try:
        asyncio.run(run_agent())
    except KeyboardInterrupt:
        print("\n  Agent oprit.")


if __name__ == "__main__":
    main()
