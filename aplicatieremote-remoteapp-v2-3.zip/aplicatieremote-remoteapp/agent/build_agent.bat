@echo off
echo ============================================
echo   Construiesc RemotePCAgent.exe ...
echo ============================================
pip install -r requirements.txt
pip install pyinstaller
pyinstaller --onefile --name RemotePCAgent --icon=icon.ico agent.py
echo.
echo Gata! Executabilul este in:  dist\RemotePCAgent.exe
echo (il dai prietenilor - il pornesc o data si vad CODUL + PAROLA)
pause
