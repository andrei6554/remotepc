@echo off
REM Instaleaza suportul pentru titlul + coperta melodiei (optional).
echo Incerc winsdk...
pip install winsdk
if %errorlevel%==0 ( echo Gata! Reporneste agentul. & pause & exit /b )
echo winsdk nu a mers, incerc winrt...
pip install winrt-runtime winrt-Windows.Media.Control winrt-Windows.Storage.Streams winrt-Windows.Foundation
echo Gata. Reporneste agentul.
pause
