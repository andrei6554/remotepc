# Remote Control PC — PRD

## Problem statement
User (RO) wants a Windows web app to remotely control a PC: power on (Wake-on-LAN),
shutdown, restart, sleep, mute, volume up/down, lock, logoff, monitor off, task manager,
screenshot, open apps + custom apps. Black background, orange icons. Password protected,
easy to use, publishable (port forwarding + ngrok), MAC entered via UI.

## Architecture
- Deliverable: standalone Flask app `/app/remote_pc/app.py` -> runs on Windows, port 5000, clean routes.
- Platform detection: real OS commands on Windows; SIMULATED ("simulat") on non-Windows (so preview works).
- Volume/mute via PowerShell SendKeys; sleep/lock/logoff/shutdown via rundll32/shutdown; monitor off via SendMessage; screenshot via PIL ImageGrab; WoL via wakeonlan.
- Config persisted in `/app/remote_pc/config.json` (password, mac, broadcast, custom_apps, secret_key).
- Preview only: `/app/backend/server.py` (FastAPI) mounts the Flask app at `/api` via a2wsgi.
- Auth: Flask session, single password (default 1234), changeable in Settings.

## Implemented (2026-06-26)
- Login + password protection (tested).
- Dashboard: Power group (start/shutdown/restart/sleep/lock/logoff/monitor_off/abort), Sound (vol+/vol-/mute), System (taskmgr/screenshot), Apps (8 builtins + custom) + "Open all".
- Screenshot modal, toast notifications, AJAX actions.
- Settings: save MAC + broadcast, change password, add/delete custom apps.
- Deliverables: app.py, requirements.txt, README.md (RO: ngrok + port forwarding + WoL/BIOS), build_exe.bat (PyInstaller), run.bat.
- Tested via testing agent: 26/27 frontend assertions pass (1 was stale test data, not a bug).

## Backlog / Next
- P1: HTTPS + rate limiting on login for safe public exposure.
- P2: Hash the password instead of plaintext in config.json.
- P2: Live system status (CPU/RAM, current volume %), media play/pause/next.
- P2: App icon (.ico) for the exe; auto-start at boot helper.

## Update 2026-06-26 (P1 + P2 done)
- P1 HTTPS: optional self-signed adhoc cert via REMOTE_PC_HTTPS env or config use_https (cryptography). ngrok already gives HTTPS.
- P1 Brute-force: per-IP login rate limiting, 5 failed attempts -> 15 min lockout (in-memory, threadsafe). Verified.
- P2 Password hashing: bcrypt ($2b$12$), auto-migrates legacy plaintext -> hash on first load. verify_password used at login + password change. Verified.
- P2 Live status: /status endpoint (psutil CPU% + RAM%, volume% via pycaw on Windows / simulated in preview), status bar polls every 2.5s. Verified.
- P2 Media keys: media_play/media_next/media_prev actions (PowerShell SendKeys media keys) + dashboard tiles. Verified.
- P2 .ico: orange power icon generated at /app/remote_pc/icon.ico, used by build_exe.bat (--icon).
- requirements.txt: added bcrypt, psutil, cryptography; pycaw + comtypes gated with `; sys_platform == "win32"`.

## Remaining backlog
- P2: app auto-start helper at Windows boot; richer media info (now-playing title); per-action confirmation for destructive ops (shutdown).

## Update 2026-06-26 (Central "TeamViewer" model built)
- Architecture switched to: central server (relay) + per-PC agent + hosted web UI.
- /app/backend/server.py = FastAPI relay (also saved as server_central.py). Endpoints: POST /api/connect, /api/command, GET /api/state, /api/cover, /api/screenshot, WS /api/ws/agent. In-memory AGENTS{code} + PENDING futures. bcrypt password verify.
- /app/agent/agent.py = WebSocket client agent. Generates code+password (agent_config.json), connects out, sends status (cpu/ram/volume/now_playing/cover), executes commands (reuses all OS actions). Packaged via build_agent.bat (.exe). Deliverable: /app/RemoteAgent.zip.
- /app/frontend (React) = central site: Connect (code+password) + Dashboard (status bar, power w/ confirm, volume slider, media, now-playing+cover, screenshot modal+download, apps with hide/reset via localStorage). Theme black/orange, App.css.
- Tested via testing agent iteration_2: 11/11 frontend flows PASS.
- Code protection: backend code stays server-side (never sent to users); agent shipped as exe; frontend JS is public by nature (no secrets in it).
- Standalone Flask app (/app/remote_pc, /app/RemotePC.zip) retained: added custom-app avatar upload from gallery + screenshot save/download + (earlier) all features.

## Next / Backlog (central model)
- To publish for non-stop use: Deploy the app; then set agent_config.json "server" to the deployed URL (or bake it into the agent default).
- Consider: send code/password via POST/headers instead of GET query (state/cover/screenshot); request timeouts; optional accounts; agent .exe code-signing/obfuscation (pyarmor).
