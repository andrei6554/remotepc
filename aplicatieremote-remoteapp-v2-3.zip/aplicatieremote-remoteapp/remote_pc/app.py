"""
Remote Control PC  -  aplicatie web pentru controlul PC-ului Windows de la distanta.
Ruleaza acest fisier pe PC-ul tau Windows:  python app.py
Apoi deschide pe telefon/alt dispozitiv:    http://IP-UL-TAU:5000
(vezi README.md pentru port forwarding / ngrok / Wake-on-LAN)
"""
import os
import json
import time
import hmac
import base64
import platform
import secrets
import threading
import subprocess
from datetime import datetime
from functools import wraps

try:
    import bcrypt
except Exception:  # pragma: no cover
    bcrypt = None

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None

from flask import (
    Flask, request, redirect, url_for, session,
    render_template_string, jsonify, send_file, Response
)

try:
    from wakeonlan import send_magic_packet
except Exception:  # pragma: no cover
    send_magic_packet = None

IS_WINDOWS = platform.system() == "Windows"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
SHOT_PATH = os.path.join(BASE_DIR, "last_screenshot.png")

DEFAULT_CONFIG = {
    "password_hash": "",
    "mac": "",
    "broadcast": "255.255.255.255",
    "secret_key": "",
    "use_https": False,
    "device_name": "PC-ul meu",
    "custom_apps": [],  # [{"id","name","command","icon"}]
}

# latest media cover art (bytes), shared across requests
LAST_COVER = {"key": None, "data": None, "mime": "image/jpeg"}

# rolling CPU usage updated by a background thread (psutil interval=0 always
# returns 0 on the first call, so we sample continuously instead)
_CPU_USAGE = {"val": None}


def _start_cpu_sampler():
    if not psutil:
        return

    def loop():
        while True:
            try:
                _CPU_USAGE["val"] = psutil.cpu_percent(interval=1.0)
            except Exception:
                time.sleep(1)

    threading.Thread(target=loop, daemon=True).start()


_start_cpu_sampler()

# --------------------------------------------------------------- auth helpers
def hash_password(pw):
    if bcrypt is None:
        return "plain$" + pw
    return bcrypt.hashpw(pw.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(pw, hashed):
    if not hashed:
        return False
    if hashed.startswith("plain$"):
        return hmac.compare_digest(hashed[6:], pw)
    if bcrypt is None:
        return False
    try:
        return bcrypt.checkpw(pw.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


# in-memory brute-force protection (per client IP)
MAX_ATTEMPTS = 5
LOCKOUT_SECS = 900  # 15 min
LOGIN_ATTEMPTS = {}
_attempts_lock = threading.Lock()


def _client_ip():
    fwd = request.headers.get("X-Forwarded-For", "")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.remote_addr or "unknown"


def check_lockout(ip):
    now = time.time()
    with _attempts_lock:
        rec = LOGIN_ATTEMPTS.get(ip)
        if rec and rec["until"] > now:
            return int(rec["until"] - now)
    return 0


def register_failure(ip):
    now = time.time()
    with _attempts_lock:
        rec = LOGIN_ATTEMPTS.get(ip, {"count": 0, "until": 0})
        rec["count"] += 1
        if rec["count"] >= MAX_ATTEMPTS:
            rec["until"] = now + LOCKOUT_SECS
            rec["count"] = 0
        LOGIN_ATTEMPTS[ip] = rec
        return MAX_ATTEMPTS - rec["count"] if rec["until"] <= now else 0


def clear_failures(ip):
    with _attempts_lock:
        LOGIN_ATTEMPTS.pop(ip, None)


# ------------------------------------------------------------------ config
def load_config():
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                cfg.update(json.load(f))
        except Exception:
            pass
    changed = False
    for k, v in DEFAULT_CONFIG.items():
        if k not in cfg:
            cfg[k] = v
            changed = True
    # migrate any legacy plaintext password to a salted hash
    if cfg.get("password") and not cfg.get("password_hash"):
        cfg["password_hash"] = hash_password(cfg["password"])
        cfg.pop("password", None)
        changed = True
    if not cfg.get("password_hash"):
        cfg["password_hash"] = hash_password("1234")
        changed = True
    if not cfg.get("secret_key"):
        cfg["secret_key"] = secrets.token_hex(16)
        changed = True
    if changed:
        save_config(cfg)
    return cfg


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


CONFIG = load_config()

app = Flask(__name__)
app.secret_key = CONFIG["secret_key"]


def init_config():
    """Re-load config (used when embedded in another server)."""
    global CONFIG
    CONFIG = load_config()
    app.secret_key = CONFIG["secret_key"]


# ------------------------------------------------------------------ helpers
def run_cmd(cmd, shell=False):
    """Run a system command. On non-Windows returns a simulated result so the
    web interface stays testable in any environment."""
    if not IS_WINDOWS:
        return True, "simulat (ruleaza pe Windows pentru efect real)"
    try:
        subprocess.Popen(cmd, shell=shell)
        return True, "comanda trimisa"
    except Exception as e:
        return False, str(e)


def run_ps(ps_command):
    if not IS_WINDOWS:
        return True, "simulat (ruleaza pe Windows pentru efect real)"
    try:
        subprocess.Popen(
            ["powershell", "-NoProfile", "-Command", ps_command],
            shell=False,
        )
        return True, "comanda trimisa"
    except Exception as e:
        return False, str(e)


def volume_key(char_code, repeat):
    if not IS_WINDOWS:
        return True, "simulat (ruleaza pe Windows pentru efect real)"
    keys = "".join("[char]%d" % char_code for _ in range(repeat))
    ps = "$o = New-Object -ComObject WScript.Shell; " + \
         ";".join(["$o.SendKeys([char]%d)" % char_code for _ in range(repeat)])
    return run_ps(ps)


MONITOR_OFF_PS = (
    "$t = Add-Type -MemberDefinition "
    "'[DllImport(\"user32.dll\")] public static extern int "
    "SendMessage(int hWnd, int hMsg, int wParam, int lParam);' "
    "-Name Win -Namespace Native -PassThru; "
    "$t::SendMessage(0xffff, 0x0112, 0xF170, 2)"
)


# action name -> (label, function)
def act_shutdown():
    return run_cmd("shutdown /s /t 3", shell=True)


def act_restart():
    return run_cmd("shutdown /r /t 3", shell=True)


def act_abort():
    return run_cmd("shutdown /a", shell=True)


def act_sleep():
    return run_cmd("rundll32.exe powrprof.dll,SetSuspendState 0,1,0", shell=True)


def act_lock():
    return run_cmd("rundll32.exe user32.dll,LockWorkStation", shell=True)


def act_logoff():
    return run_cmd("shutdown /l", shell=True)


def act_monitor_off():
    return run_ps(MONITOR_OFF_PS)


def act_mute():
    return volume_key(173, 1)


def act_vol_up():
    return volume_key(175, 5)


def act_vol_down():
    return volume_key(174, 5)


def act_media_play():
    return volume_key(179, 1)  # play/pause media key


def act_media_next():
    return volume_key(176, 1)  # next track


def act_media_prev():
    return volume_key(177, 1)  # previous track


SIM_VOLUME = 42  # simulated volume used in non-Windows preview


def _endpoint_volume():
    from ctypes import cast, POINTER
    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
    spk = AudioUtilities.GetSpeakers()
    # some pycaw versions return a wrapped AudioDevice (no .Activate);
    # unwrap to the underlying IMMDevice if needed
    if not hasattr(spk, "Activate"):
        spk = getattr(spk, "_dev", None) or spk
    interface = spk.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    return cast(interface, POINTER(IAudioEndpointVolume))


def get_volume_percent():
    if not IS_WINDOWS:
        return SIM_VOLUME
    try:
        return int(round(_endpoint_volume().GetMasterVolumeLevelScalar() * 100))
    except Exception:
        return None


def apply_volume(pct):
    global SIM_VOLUME
    pct = max(0, min(100, int(pct)))
    if not IS_WINDOWS:
        SIM_VOLUME = pct
        return True, "Volum setat la %d%% (simulat)" % pct
    try:
        _endpoint_volume().SetMasterVolumeLevelScalar(pct / 100.0, None)
        return True, "Volum setat la %d%%" % pct
    except Exception as e:
        return False, str(e)


def _make_demo_cover():
    try:
        import io
        from PIL import Image, ImageDraw
        img = Image.new("RGB", (300, 300), (18, 18, 20))
        d = ImageDraw.Draw(img)
        d.ellipse([60, 60, 240, 240], outline=(255, 138, 0), width=10)
        d.ellipse([135, 135, 165, 165], fill=(255, 138, 0))
        b = io.BytesIO()
        img.save(b, "PNG")
        LAST_COVER["key"] = "demo"
        LAST_COVER["data"] = b.getvalue()
        LAST_COVER["mime"] = "image/png"
    except Exception:
        pass


def get_now_playing():
    if not IS_WINDOWS:
        dur = 210
        pos = int(time.time()) % dur
        if LAST_COVER["key"] != "demo":
            _make_demo_cover()
        return {"title": "Demo Song (simulat)", "artist": "Spotify",
                "position": pos, "duration": dur, "cover": bool(LAST_COVER["data"])}
    try:
        import asyncio
        try:
            from winsdk.windows.media.control import (
                GlobalSystemMediaTransportControlsSessionManager as MediaManager,
            )
            from winsdk.windows.storage.streams import DataReader
        except Exception:
            from winrt.windows.media.control import (
                GlobalSystemMediaTransportControlsSessionManager as MediaManager,
            )
            from winrt.windows.storage.streams import DataReader

        async def _get():
            mgr = await MediaManager.request_async()
            sess = mgr.get_current_session()
            if not sess:
                return None
            info = await sess.try_get_media_properties_async()
            title = (info.title or "").strip()
            if not title:
                return None
            artist = (info.artist or "").strip()
            pos = dur = 0
            try:
                tl = sess.get_timeline_properties()
                pos = int(tl.position.total_seconds()) if tl.position else 0
                dur = int(tl.end_time.total_seconds()) if tl.end_time else 0
            except Exception:
                pass
            cover = False
            try:
                key = title + "|" + artist
                thumb = info.thumbnail
                if thumb is not None:
                    stream = await thumb.open_read_async()
                    size = stream.size
                    if size and size > 0:
                        reader = DataReader(stream)
                        await reader.load_async(size)
                        buf = bytearray(size)
                        reader.read_bytes(buf)
                        LAST_COVER["key"] = key
                        LAST_COVER["data"] = bytes(buf)
                        LAST_COVER["mime"] = stream.content_type or "image/jpeg"
                        cover = True
            except Exception:
                pass
            return {"title": title, "artist": artist,
                    "position": pos, "duration": dur, "cover": cover}

        return asyncio.run(_get())
    except Exception:
        return None


def act_taskmgr():
    return run_cmd("taskmgr", shell=True)


# ------------------------------------------------------------------ screen stream
def _capture_frame_jpeg(quality=40):
    """Captureaza un frame de ecran si returneaza bytes JPEG."""
    try:
        from PIL import ImageGrab
        import io
        img = ImageGrab.grab()
        w, h = img.size
        if w > 1280:
            ratio = 1280 / w
            img = img.resize((1280, int(h * ratio)))
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=quality)
        return buf.getvalue()
    except Exception:
        return None


def _generate_screen_stream():
    """Generator MJPEG pentru live stream ecran (~6 fps)."""
    boundary = b"--frame"
    while True:
        frame = _capture_frame_jpeg(quality=35)
        if frame:
            yield (boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
        time.sleep(0.15)


# ------------------------------------------------------------------ procese deschise
def get_running_apps():
    """Returneaza lista proceselor cu ferestre vizibile."""
    if not IS_WINDOWS:
        return [
            {"pid": 1234, "name": "chrome.exe", "title": "Google Chrome"},
            {"pid": 5678, "name": "notepad.exe", "title": "Notepad"},
            {"pid": 9012, "name": "explorer.exe", "title": "Windows Explorer"},
            {"pid": 3456, "name": "code.exe", "title": "Visual Studio Code"},
        ]
    try:
        import ctypes
        EnumWindows = ctypes.windll.user32.EnumWindows
        GetWindowText = ctypes.windll.user32.GetWindowTextW
        GetWindowTextLength = ctypes.windll.user32.GetWindowTextLengthW
        IsWindowVisible = ctypes.windll.user32.IsWindowVisible
        GetWindowThreadProcessId = ctypes.windll.user32.GetWindowThreadProcessId

        apps = []
        pid_seen = set()

        def _cb(hwnd, _):
            if not IsWindowVisible(hwnd):
                return True
            length = GetWindowTextLength(hwnd)
            if length == 0:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            GetWindowText(hwnd, buf, length + 1)
            title = buf.value.strip()
            if not title:
                return True
            pid = ctypes.c_ulong()
            GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            pid_val = pid.value
            if pid_val in pid_seen:
                return True
            pid_seen.add(pid_val)
            name = "necunoscut"
            if psutil:
                try:
                    name = psutil.Process(pid_val).name()
                except Exception:
                    pass
            apps.append({"pid": pid_val, "name": name, "title": title})
            return True

        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
        EnumWindows(WNDENUMPROC(_cb), 0)
        return sorted(apps, key=lambda x: x["title"].lower())
    except Exception:
        return []


def kill_process(pid):
    """Inchide un proces dupa PID."""
    if not IS_WINDOWS:
        return True, "simulat (inchis pid %d)" % pid
    try:
        if psutil:
            psutil.Process(pid).terminate()
            return True, "Procesul %d a fost inchis" % pid
        subprocess.Popen(["taskkill", "/PID", str(pid), "/F"])
        return True, "Procesul %d a fost inchis" % pid
    except Exception as e:
        return False, str(e)


def act_start_pc():
    mac = CONFIG.get("mac", "").strip()
    if not mac:
        return False, "Adresa MAC nu este setata. Mergi la Setari si completeaz-o."
    if send_magic_packet is None:
        return False, "Modulul wakeonlan nu este instalat (pip install wakeonlan)."
    try:
        send_magic_packet(mac, ip_address=CONFIG.get("broadcast", "255.255.255.255"))
        return True, "Semnal Wake-on-LAN trimis catre " + mac
    except Exception as e:
        return False, str(e)


def act_screenshot():
    if not IS_WINDOWS:
        # create a placeholder so the UI flow works in preview
        try:
            from PIL import Image, ImageDraw
            img = Image.new("RGB", (640, 360), (10, 10, 10))
            d = ImageDraw.Draw(img)
            d.text((20, 20), "Screenshot simulat - ruleaza pe Windows", fill=(255, 138, 0))
            d.text((20, 60), datetime.now().strftime("%Y-%m-%d %H:%M:%S"), fill=(255, 255, 255))
            img.save(SHOT_PATH)
            return True, "screenshot simulat creat"
        except Exception as e:
            return False, str(e)
    try:
        from PIL import ImageGrab
        img = ImageGrab.grab()
        img.save(SHOT_PATH)
        return True, "screenshot capturat"
    except Exception as e:
        return False, "Eroare screenshot (pip install pillow): " + str(e)


ACTIONS = {
    "start": ("Pornește PC", act_start_pc),
    "shutdown": ("Oprește PC", act_shutdown),
    "restart": ("Repornește PC", act_restart),
    "abort": ("Anulează oprirea", act_abort),
    "sleep": ("Sleep", act_sleep),
    "lock": ("Blochează", act_lock),
    "logoff": ("Deconectare", act_logoff),
    "monitor_off": ("Oprește monitor", act_monitor_off),
    "mute": ("Mute", act_mute),
    "vol_up": ("Volum +", act_vol_up),
    "vol_down": ("Volum -", act_vol_down),
    "media_play": ("Play/Pauză", act_media_play),
    "media_next": ("Următor", act_media_next),
    "media_prev": ("Anterior", act_media_prev),
    "taskmgr": ("Task Manager", act_taskmgr),
    "screenshot": ("Screenshot", act_screenshot),
}

BUILTIN_APPS = [
    {"id": "chrome", "name": "Chrome", "command": "start chrome", "icon": "fa-brands fa-chrome"},
    {"id": "notepad", "name": "Notepad", "command": "notepad", "icon": "fa-regular fa-file-lines"},
    {"id": "calc", "name": "Calculator", "command": "calc", "icon": "fa-solid fa-calculator"},
    {"id": "explorer", "name": "Explorer", "command": "explorer", "icon": "fa-regular fa-folder-open"},
    {"id": "spotify", "name": "Spotify", "command": "start \"\" spotify:", "icon": "fa-brands fa-spotify"},
    {"id": "cmd", "name": "Terminal", "command": "start cmd", "icon": "fa-solid fa-terminal"},
    {"id": "settings", "name": "Setări Windows", "command": "start ms-settings:", "icon": "fa-solid fa-gear"},
    {"id": "edge", "name": "Edge", "command": "start msedge", "icon": "fa-brands fa-edge"},
]


def find_app(app_id):
    for a in BUILTIN_APPS:
        if a["id"] == app_id:
            return a
    for a in CONFIG.get("custom_apps", []):
        if a["id"] == app_id:
            return a
    return None


# ------------------------------------------------------------------ auth
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("auth"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


# ------------------------------------------------------------------ templates
LOGIN_HTML = """
<!DOCTYPE html><html lang="ro"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Remote PC · Login</title>
<meta name="theme-color" content="#ff7a00">
<link rel="manifest" href="{{ url_for('manifest') }}">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Remote PC">
<link rel="apple-touch-icon" href="{{ url_for('icon_apple') }}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>{{ css }}</style></head>
<body class="login-body">
<div class="login-card">
  <div class="logo"><i class="fa-solid fa-power-off"></i></div>
  <h1>Remote <span>PC</span></h1>
  <p class="sub">Controlează-ți calculatorul de oriunde</p>
  {% if error %}<div class="error" data-testid="login-error">{{ error }}</div>{% endif %}
  <form method="post" action="{{ url_for('login') }}">
    <div class="field">
      <i class="fa-solid fa-lock"></i>
      <input type="password" name="password" placeholder="Parolă" autofocus
             data-testid="login-password-input" required>
    </div>
    <button type="submit" class="btn-main" data-testid="login-submit-button">
      <i class="fa-solid fa-right-to-bracket"></i> Intră
    </button>
  </form>
  <p class="hint">Parola implicită: <b>1234</b> · o poți schimba din Setări</p>
</div>
<script>
if('serviceWorker' in navigator){ navigator.serviceWorker.register("{{ url_for('service_worker') }}").catch(function(){}); }
</script>
</body></html>
"""

DASH_HTML = """
<!DOCTYPE html><html lang="ro"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Remote PC</title>
<meta name="theme-color" content="#ff7a00">
<link rel="manifest" href="{{ url_for('manifest') }}">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Remote PC">
<link rel="apple-touch-icon" href="{{ url_for('icon_apple') }}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>{{ css }}</style></head>
<body>
<header class="topbar">
  <div class="brand"><i class="fa-solid fa-power-off"></i> {{ device_name }}</div>
  <div class="status">
    <span class="dot {{ 'live' if is_windows else 'sim' }}"></span>
    {{ 'Windows · LIVE' if is_windows else 'Preview · SIMULAT' }}
  </div>
  <div class="actions">
    <button id="install-btn" class="icon-btn install-pulse" data-testid="install-btn" title="Instalează pe telefon"><i class="fa-solid fa-mobile-screen-button"></i></button>
    <a href="{{ url_for('settings') }}" class="icon-btn" data-testid="nav-settings" title="Setări"><i class="fa-solid fa-gear"></i></a>
    <a href="{{ url_for('logout') }}" class="icon-btn" data-testid="nav-logout" title="Ieși"><i class="fa-solid fa-arrow-right-from-bracket"></i></a>
  </div>
</header>

<main class="wrap">
  <section class="statusbar" data-testid="status-bar">
    <div class="stat"><span class="lbl"><i class="fa-solid fa-microchip"></i> CPU</span><span class="val" id="st-cpu" data-testid="stat-cpu">—</span></div>
    <div class="stat"><span class="lbl"><i class="fa-solid fa-memory"></i> Memorie</span><span class="val" id="st-ram" data-testid="stat-ram">—</span></div>
    <div class="stat"><span class="lbl"><i class="fa-solid fa-volume-high"></i> Volum</span><span class="val" id="st-vol" data-testid="stat-volume">—</span></div>
  </section>

  <section class="group">
    <h2><i class="fa-solid fa-plug-circle-bolt"></i> Alimentare</h2>
    <div class="grid">
      {{ tile('start',       'fa-solid fa-power-off',          'Pornește PC',  'green') }}
      {{ tile('shutdown',    'fa-solid fa-power-off',          'Oprește PC',   'red',   'Sigur vrei să OPREȘTI PC-ul?') }}
      {{ tile('restart',     'fa-solid fa-rotate-right',       'Repornește',   'amber', 'Sigur vrei să REPORNEȘTI PC-ul?') }}
      {{ tile('sleep',       'fa-solid fa-moon',               'Sleep',        'orange') }}
      {{ tile('lock',        'fa-solid fa-lock',               'Blochează',    'orange') }}
      {{ tile('logoff',      'fa-solid fa-right-from-bracket', 'Deconectare',  'orange', 'Sigur vrei să te DECONECTEZI?') }}
      {{ tile('monitor_off', 'fa-solid fa-display',            'Oprește ecran','orange') }}
      {{ tile('abort',       'fa-solid fa-ban',                'Anulează oprirea','orange') }}
    </div>
  </section>

  <section class="group">
    <h2><i class="fa-solid fa-volume-high"></i> Sunet & Media</h2>
    <div class="nowplaying" id="nowplaying" data-testid="now-playing" style="display:none">
      <img id="np-cover" class="np-cover" alt="" style="display:none">
      <div class="np-info">
        <div class="np-head"><i class="fa-solid fa-music"></i> <span id="np-text"></span></div>
        <div class="progress-row" id="progress-row" style="display:none">
          <span id="np-pos" class="np-time">0:00</span>
          <div class="bar"><div class="fill" id="np-fill"></div></div>
          <span id="np-dur" class="np-time">0:00</span>
        </div>
      </div>
    </div>
    <div class="vol-row" data-testid="volume-control">
      <i class="fa-solid fa-volume-low"></i>
      <input type="range" id="vol-slider" min="0" max="100" value="42" data-testid="volume-slider">
      <span id="vol-val" class="vol-val" data-testid="volume-value">42%</span>
    </div>
    <div class="grid">
      {{ tile('vol_up',   'fa-solid fa-volume-high', 'Volum +',  'orange') }}
      {{ tile('vol_down', 'fa-solid fa-volume-low',  'Volum -',  'orange') }}
      {{ tile('mute',     'fa-solid fa-volume-xmark','Mute',     'orange') }}
      {{ tile('media_play','fa-solid fa-play',        'Play/Pauză','green') }}
      {{ tile('media_prev','fa-solid fa-backward-step','Anterior', 'orange') }}
      {{ tile('media_next','fa-solid fa-forward-step', 'Următor',  'orange') }}
    </div>
  </section>

  <section class="group">
    <h2><i class="fa-solid fa-screwdriver-wrench"></i> Sistem</h2>
    <div class="grid">
      {{ tile('taskmgr',    'fa-solid fa-list-check', 'Task Manager', 'orange') }}
      {{ tile('screenshot', 'fa-solid fa-camera',     'Screenshot',   'orange') }}
    </div>
  </section>

  <section class="group">
    <div class="group-head">
      <h2><i class="fa-solid fa-display"></i> Ecran Live</h2>
      <button class="mini-btn" id="stream-toggle-btn" onclick="toggleStream()">
        <i class="fa-solid fa-play" id="stream-icon"></i> <span id="stream-label">Pornește</span>
      </button>
    </div>
    <div id="stream-container" style="display:none;position:relative;background:#000;border-radius:10px;overflow:hidden;margin-top:8px;">
      <img id="live-stream-img" style="width:100%;display:block;" alt="Live Screen">
      <div style="position:absolute;top:6px;right:8px;background:rgba(0,0,0,.6);color:#ff7a00;font-size:11px;padding:2px 8px;border-radius:20px;">
        <i class="fa-solid fa-circle" style="font-size:7px;color:#f00;animation:blink 1s infinite;"></i> LIVE
      </div>
    </div>
  </section>

  <section class="group" id="processes-section">
    <div class="group-head">
      <h2><i class="fa-solid fa-window-restore"></i> Aplicații Deschise</h2>
      <button class="mini-btn" onclick="refreshProcesses()">
        <i class="fa-solid fa-rotate"></i> Actualizează
      </button>
    </div>
    <div id="processes-list" style="margin-top:8px;">
      <p class="muted" style="text-align:center;padding:12px;">Apasă „Actualizează" pentru a vedea aplicațiile deschise.</p>
    </div>
  </section>

  <section class="group">
    <div class="group-head">
      <h2><i class="fa-solid fa-grip"></i> Aplicații</h2>
      <button class="mini-btn" data-testid="open-all-apps-button" onclick="openAll()">
        <i class="fa-solid fa-layer-group"></i> Deschide tot
      </button>
    </div>
    <div class="grid">
      {% for a in builtin_apps %}{{ apptile(a) }}{% endfor %}
      {% for a in custom_apps %}{{ apptile(a, true) }}{% endfor %}
    </div>
  </section>
</main>

<div id="screenshot-modal" class="modal" data-testid="screenshot-modal">
  <div class="modal-inner">
    <button class="modal-close" onclick="closeShot()"><i class="fa-solid fa-xmark"></i></button>
    <img id="shot-img" alt="screenshot">
    <a id="shot-dl" class="modal-dl" download="screenshot.png" data-testid="screenshot-download"><i class="fa-solid fa-download"></i> Salvează poza</a>
  </div>
</div>

<div id="confirm-modal" class="modal" data-testid="confirm-modal">
  <div class="confirm-box">
    <div class="confirm-ic"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <p id="confirm-text">Ești sigur?</p>
    <div class="confirm-actions">
      <button class="btn-ghost" data-testid="confirm-cancel" onclick="cancelConfirm()">Nu, anulează</button>
      <button class="btn-danger" data-testid="confirm-ok" onclick="okConfirm()">Da, continuă</button>
    </div>
  </div>
</div>

<div id="install-modal" class="modal" data-testid="install-modal">
  <div class="confirm-box install-box">
    <div class="confirm-ic install-ic"><i class="fa-solid fa-mobile-screen-button"></i></div>
    <p style="text-align:center">Pune „Remote PC" pe ecranul telefonului</p>
    <div class="install-steps">
      <div class="step"><b><i class="fa-brands fa-android"></i> Android (Chrome)</b>
        <span>Apasă meniul <b>⋮</b> (dreapta sus) → <b>„Adaugă la ecranul de start"</b> / „Install app".</span></div>
      <div class="step"><b><i class="fa-brands fa-apple"></i> iPhone (Safari)</b>
        <span>Apasă <b>„Share"</b> (pătrățel cu săgeată, jos) → <b>„Add to Home Screen"</b>.</span></div>
    </div>
    <div class="confirm-actions">
      <button class="btn-main" data-testid="install-help-ok" onclick="closeInstallHelp()">Am înțeles</button>
    </div>
  </div>
</div>

<div id="toast" class="toast" data-testid="toast"></div>

<script>
const BASE = "{{ base_url }}";
let _pendingAction = null;
function onTile(el, name){
  const c = el.getAttribute('data-confirm');
  if(c){
    _pendingAction = {name: name, el: el};
    document.getElementById('confirm-text').textContent = c;
    document.getElementById('confirm-modal').classList.add('open');
  } else {
    doAction(name, el);
  }
}
function cancelConfirm(){
  document.getElementById('confirm-modal').classList.remove('open');
  _pendingAction = null;
}
function okConfirm(){
  document.getElementById('confirm-modal').classList.remove('open');
  if(_pendingAction){ doAction(_pendingAction.name, _pendingAction.el); _pendingAction = null; }
}
function toast(msg, ok){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show ' + (ok ? 'ok' : 'err');
  clearTimeout(window._tt);
  window._tt = setTimeout(()=>{ t.className='toast'; }, 3000);
}
async function doAction(name, el){
  if(el){ el.classList.add('busy'); }
  try{
    const r = await fetch(BASE + 'action/' + name, {method:'POST'});
    const d = await r.json();
    toast(d.message, d.ok);
    if(name === 'screenshot' && d.ok){ showShot(); }
  }catch(e){ toast('Eroare de conexiune', false); }
  if(el){ setTimeout(()=>el.classList.remove('busy'), 400); }
}
async function openApp(id, el){
  if(el){ el.classList.add('busy'); }
  try{
    const r = await fetch(BASE + 'app/open/' + id, {method:'POST'});
    const d = await r.json();
    toast(d.message, d.ok);
  }catch(e){ toast('Eroare de conexiune', false); }
  if(el){ setTimeout(()=>el.classList.remove('busy'), 400); }
}
async function openAll(){
  try{
    const r = await fetch(BASE + 'app/open_all', {method:'POST'});
    const d = await r.json();
    toast(d.message, d.ok);
  }catch(e){ toast('Eroare de conexiune', false); }
}
function showShot(){
  const src = BASE + 'screenshot/view?t=' + Date.now();
  document.getElementById('shot-img').src = src;
  document.getElementById('shot-dl').href = src;
  document.getElementById('screenshot-modal').classList.add('open');
}
function closeShot(){ document.getElementById('screenshot-modal').classList.remove('open'); }
function fmtTime(s){ s=Math.max(0,Math.floor(s)); const m=Math.floor(s/60); return m+':'+String(s%60).padStart(2,'0'); }
let _volDragging = false;
const volSlider = document.getElementById('vol-slider');
volSlider.addEventListener('input', () => {
  _volDragging = true;
  document.getElementById('vol-val').textContent = volSlider.value + '%';
});
volSlider.addEventListener('change', async () => {
  try{
    const r = await fetch(BASE + 'volume', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'value=' + volSlider.value});
    const d = await r.json();
    toast(d.message, d.ok);
  }catch(e){ toast('Eroare de conexiune', false); }
  setTimeout(()=>{ _volDragging = false; }, 700);
});
async function pollStatus(){
  try{
    const r = await fetch(BASE + 'status');
    const d = await r.json();
    document.getElementById('st-cpu').textContent = (d.cpu==null?'—':d.cpu + '%');
    document.getElementById('st-ram').textContent = (d.ram==null?'—':d.ram + '%');
    document.getElementById('st-vol').textContent = (d.volume==null?'—':d.volume + '%');
    if(!_volDragging && d.volume!=null){
      volSlider.value = d.volume;
      document.getElementById('vol-val').textContent = d.volume + '%';
    }
    const np = document.getElementById('nowplaying');
    const pr = document.getElementById('progress-row');
    if(d.now_playing && d.now_playing.title){
      const a = d.now_playing.artist ? (' — ' + d.now_playing.artist) : '';
      document.getElementById('np-text').textContent = d.now_playing.title + a;
      np.style.display = '';
      const pos = d.now_playing.position||0, dur = d.now_playing.duration||0;
      if(dur > 0){
        document.getElementById('np-fill').style.width = Math.min(100, pos/dur*100) + '%';
        document.getElementById('np-pos').textContent = fmtTime(pos);
        document.getElementById('np-dur').textContent = fmtTime(dur);
        pr.style.display = '';
      } else { pr.style.display = 'none'; }
      const cover = document.getElementById('np-cover');
      if(d.now_playing.cover){
        const k = encodeURIComponent((d.now_playing.title||'') + (d.now_playing.artist||''));
        const src = BASE + 'now_playing/cover?k=' + k;
        if(cover.getAttribute('data-k') !== k){ cover.src = src; cover.setAttribute('data-k', k); }
        cover.style.display = '';
      } else { cover.style.display = 'none'; }
    } else {
      np.style.display = 'none';
    }
  }catch(e){}
}
pollStatus();
setInterval(pollStatus, 2500);

// --- Live Screen Stream ---
let _streaming = false;
let _streamTimer = null;
function _fetchFrame(){
  if(!_streaming) return;
  const img = document.getElementById('live-stream-img');
  const next = new Image();
  next.onload = function(){ img.src = next.src; if(_streaming) _streamTimer = setTimeout(_fetchFrame, 500); };
  next.onerror = function(){ if(_streaming) _streamTimer = setTimeout(_fetchFrame, 1000); };
  next.src = BASE + 'screen/frame?t=' + Date.now();
}
function toggleStream(){
  const cont = document.getElementById('stream-container');
  const icon = document.getElementById('stream-icon');
  const lbl = document.getElementById('stream-label');
  _streaming = !_streaming;
  if(_streaming){
    cont.style.display = '';
    icon.className = 'fa-solid fa-stop';
    lbl.textContent = 'Oprește';
    _fetchFrame();
  } else {
    clearTimeout(_streamTimer);
    document.getElementById('live-stream-img').src = '';
    cont.style.display = 'none';
    icon.className = 'fa-solid fa-play';
    lbl.textContent = 'Pornește';
  }
}

// --- Procese Deschise ---
async function refreshProcesses(){
  const list = document.getElementById('processes-list');
  list.innerHTML = '<p class="muted" style="text-align:center;padding:12px;"><i class="fa-solid fa-spinner fa-spin"></i> Se încarcă...</p>';
  try{
    const r = await fetch(BASE + 'processes');
    const d = await r.json();
    if(!d.apps || d.apps.length === 0){
      list.innerHTML = '<p class="muted" style="text-align:center;padding:12px;">Nu s-au găsit aplicații deschise.</p>';
      return;
    }
    list.innerHTML = d.apps.map(a => `
      <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;background:rgba(255,255,255,.04);margin-bottom:6px;">
        <i class="fa-solid fa-window-maximize" style="color:#ff7a00;font-size:13px;flex-shrink:0;"></i>
        <div style="flex:1;min-width:0;">
          <div style="font-weight:600;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escHtml(a.title)}</div>
          <div style="font-size:10px;color:#888;">${escHtml(a.name)} · PID ${a.pid}</div>
        </div>
        <button onclick="killProc(${a.pid}, this)" style="background:rgba(255,60,60,.15);border:1px solid rgba(255,60,60,.3);color:#ff6060;border-radius:6px;padding:4px 10px;font-size:12px;cursor:pointer;flex-shrink:0;" title="Închide aplicația">
          <i class="fa-solid fa-xmark"></i> Închide
        </button>
      </div>
    `).join('');
  }catch(e){ list.innerHTML = '<p class="muted" style="text-align:center;padding:12px;">Eroare de conexiune.</p>'; }
}
function escHtml(s){ const d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
async function killProc(pid, btn){
  btn.disabled = true;
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';
  try{
    const r = await fetch(BASE + 'processes/kill', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({pid})});
    const d = await r.json();
    toast(d.message, d.ok);
    if(d.ok){ btn.closest('div[style]').remove(); }
    else { btn.disabled=false; btn.innerHTML='<i class="fa-solid fa-xmark"></i> Închide'; }
  }catch(e){ toast('Eroare', false); btn.disabled=false; btn.innerHTML='<i class="fa-solid fa-xmark"></i> Închide'; }
}
refreshProcesses();


if('serviceWorker' in navigator){
  navigator.serviceWorker.register(BASE + 'sw.js').catch(()=>{});
}
let _deferredPrompt = null;
const installBtn = document.getElementById('install-btn');
function closeInstallHelp(){ document.getElementById('install-modal').classList.remove('open'); }
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  _deferredPrompt = e;
});
if(installBtn){
  installBtn.addEventListener('click', async () => {
    if(_deferredPrompt){
      _deferredPrompt.prompt();
      await _deferredPrompt.userChoice;
      _deferredPrompt = null;
    } else {
      document.getElementById('install-modal').classList.add('open');
    }
  });
}
window.addEventListener('appinstalled', () => { if(installBtn) installBtn.style.display = 'none'; });
</script>
</body></html>
"""

SETTINGS_HTML = """
<!DOCTYPE html><html lang="ro"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Remote PC · Setări</title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>{{ css }}</style></head>
<body>
<header class="topbar">
  <div class="brand"><i class="fa-solid fa-gear"></i> Setări</div>
  <div class="actions">
    <a href="{{ url_for('home') }}" class="icon-btn" data-testid="nav-home" title="Înapoi"><i class="fa-solid fa-house"></i></a>
  </div>
</header>
<main class="wrap settings">
  {% if msg %}<div class="ok-banner" data-testid="settings-message">{{ msg }}</div>{% endif %}

  <section class="card">
    <h2><i class="fa-solid fa-display"></i> Nume dispozitiv</h2>
    <p class="muted">Numele afișat în partea de sus a aplicației (ex: „PC Birou", „Laptop Gaming").</p>
    <form method="post" action="{{ url_for('settings') }}">
      <input type="hidden" name="form" value="device">
      <label>Nume PC</label>
      <input name="device_name" value="{{ cfg.device_name }}" placeholder="PC-ul meu" data-testid="settings-device-input" maxlength="40">
      <button class="btn-main" data-testid="settings-save-device"><i class="fa-solid fa-floppy-disk"></i> Salvează</button>
    </form>
  </section>

  <section class="card">
    <h2><i class="fa-solid fa-network-wired"></i> Wake-on-LAN</h2>
    <p class="muted">Adresa MAC a PC-ului pe care vrei să-l pornești de la distanță.</p>
    <form method="post" action="{{ url_for('settings') }}">
      <input type="hidden" name="form" value="wol">
      <label>Adresă MAC</label>
      <input name="mac" value="{{ cfg.mac }}" placeholder="AA:BB:CC:DD:EE:FF" data-testid="settings-mac-input">
      <label>Broadcast IP (opțional)</label>
      <input name="broadcast" value="{{ cfg.broadcast }}" placeholder="255.255.255.255" data-testid="settings-broadcast-input">
      <button class="btn-main" data-testid="settings-save-wol"><i class="fa-solid fa-floppy-disk"></i> Salvează</button>
    </form>
  </section>

  <section class="card">
    <h2><i class="fa-solid fa-key"></i> Parolă</h2>
    <form method="post" action="{{ url_for('settings') }}">
      <input type="hidden" name="form" value="password">
      <label>Parolă nouă</label>
      <input type="password" name="password" placeholder="Parolă nouă" data-testid="settings-password-input" required>
      <button class="btn-main" data-testid="settings-save-password"><i class="fa-solid fa-floppy-disk"></i> Schimbă parola</button>
    </form>
  </section>

  <section class="card">
    <h2><i class="fa-solid fa-square-plus"></i> Aplicații personalizate</h2>
    <p class="muted">Adaugă orice program prin cale completă sau comandă (ex: <code>C:\\Jocuri\\joc.exe</code> sau <code>start spotify</code>). Poți pune și o poză din galerie ca iconiță.</p>
    <form method="post" action="{{ url_for('add_app') }}" enctype="multipart/form-data" class="addapp-form">
      <input name="name" placeholder="Nume (ex: Steam)" data-testid="app-name-input" required>
      <input name="command" placeholder="Comandă / cale (ex: start steam)" data-testid="app-command-input" required>
      <label class="avatar-pick">
        <i class="fa-solid fa-image"></i> <span id="avatar-label">Alege poză din galerie (opțional)</span>
        <input type="file" name="avatar" accept="image/*" data-testid="app-avatar-input" hidden
               onchange="document.getElementById('avatar-label').textContent = this.files.length ? this.files[0].name : 'Alege poză din galerie (opțional)'">
      </label>
      <button class="btn-main" data-testid="add-app-button"><i class="fa-solid fa-plus"></i> Adaugă aplicația</button>
    </form>
    <div class="applist" data-testid="custom-apps-list">
      {% for a in cfg.custom_apps %}
      <div class="appitem">
        <span>
          {% if a.avatar %}<img src="{{ a.avatar }}" class="appitem-avatar" alt="">{% else %}<i class="fa-solid fa-cube"></i>{% endif %}
          {{ a.name }} <code>{{ a.command }}</code>
        </span>
        <form method="post" action="{{ url_for('delete_app') }}">
          <input type="hidden" name="id" value="{{ a.id }}">
          <button class="del-btn" data-testid="delete-app-{{ a.id }}"><i class="fa-solid fa-trash"></i></button>
        </form>
      </div>
      {% else %}
      <p class="muted">Nicio aplicație personalizată încă.</p>
      {% endfor %}
    </div>
  </section>
</main>
</body></html>
"""

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0a0a0a;--panel:#141414;--panel2:#1c1c1c;--line:#262626;--or:#ff7a00;--or2:#ff9d3d;--txt:#f2f2f2;--mut:#8a8a8a;--green:#27c93f;--red:#ff4d4d;--amber:#ffb020}
body{background:var(--bg);color:var(--txt);font-family:'Sora',system-ui,sans-serif;min-height:100vh}
body::before{content:"";position:fixed;inset:0;background:radial-gradient(900px 500px at 80% -10%,rgba(255,122,0,.10),transparent 60%);pointer-events:none;z-index:0}
.topbar{position:sticky;top:0;z-index:5;display:flex;align-items:center;gap:16px;padding:16px 22px;background:rgba(12,12,12,.85);backdrop-filter:blur(14px);border-bottom:1px solid var(--line)}
.brand{font-weight:800;font-size:20px;letter-spacing:-.4px}
.brand i,.brand span{color:var(--or)}
.status{margin-left:8px;font-size:12px;color:var(--mut);display:flex;align-items:center;gap:7px;border:1px solid var(--line);padding:5px 10px;border-radius:999px}
.dot{width:8px;height:8px;border-radius:50%}
.dot.live{background:var(--green);box-shadow:0 0 8px var(--green)}
.dot.sim{background:var(--amber);box-shadow:0 0 8px var(--amber)}
.actions{margin-left:auto;display:flex;gap:10px}
.icon-btn{width:42px;height:42px;display:grid;place-items:center;border-radius:12px;background:var(--panel);border:1px solid var(--line);color:var(--txt);text-decoration:none;transition:background-color .15s,color .15s,transform .15s}
.icon-btn:hover{color:var(--or);border-color:var(--or);transform:translateY(-2px)}
.wrap{position:relative;z-index:1;max-width:1080px;margin:0 auto;padding:30px 22px 80px}
.group{margin-bottom:38px;animation:rise .5s both}
.group:nth-child(2){animation-delay:.05s}.group:nth-child(3){animation-delay:.1s}.group:nth-child(4){animation-delay:.15s}
.group-head{display:flex;align-items:center;justify-content:space-between}
.group h2{font-size:14px;text-transform:uppercase;letter-spacing:2px;color:var(--mut);margin-bottom:16px;font-weight:700}
.group h2 i{color:var(--or);margin-right:8px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:16px}
.tile{background:linear-gradient(180deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:18px;padding:24px 14px;text-align:center;cursor:pointer;transition:transform .18s,border-color .18s,box-shadow .18s;position:relative;overflow:hidden}
.tile:hover{transform:translateY(-4px);border-color:var(--or);box-shadow:0 12px 30px rgba(255,122,0,.18)}
.tile:active{transform:scale(.97)}
.tile .ic{font-size:30px;margin-bottom:12px;color:var(--or)}
.tile.green .ic{color:var(--green)}.tile.red .ic{color:var(--red)}.tile.amber .ic{color:var(--amber)}
.tile .lb{font-size:13.5px;font-weight:600}
.tile.busy{opacity:.55;pointer-events:none}
.tile.busy::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,transparent,rgba(255,122,0,.18),transparent);animation:sweep .8s infinite}
.mini-btn{background:var(--or);color:#1a0e00;border:none;font-weight:700;font-family:inherit;padding:8px 14px;border-radius:10px;cursor:pointer;display:flex;align-items:center;gap:7px;transition:transform .15s,background-color .15s}
.mini-btn:hover{background:var(--or2);transform:translateY(-2px)}
.toast{position:fixed;left:50%;bottom:30px;transform:translateX(-50%) translateY(30px);background:var(--panel2);border:1px solid var(--line);color:var(--txt);padding:14px 22px;border-radius:14px;font-weight:600;opacity:0;pointer-events:none;transition:opacity .25s,transform .25s;z-index:50;max-width:90vw;text-align:center}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
.toast.ok{border-color:var(--green)}.toast.ok::before{content:"\\f00c";font-family:"Font Awesome 6 Free";font-weight:900;color:var(--green);margin-right:8px}
.toast.err{border-color:var(--red)}.toast.err::before{content:"\\f071";font-family:"Font Awesome 6 Free";font-weight:900;color:var(--red);margin-right:8px}
.modal{position:fixed;inset:0;background:rgba(0,0,0,.85);display:none;align-items:center;justify-content:center;z-index:60;padding:20px}
.modal.open{display:flex}
.modal-inner{position:relative;max-width:96vw;max-height:90vh}
.modal-inner img{max-width:100%;max-height:88vh;border-radius:12px;border:1px solid var(--or)}
.modal-close{position:absolute;top:-14px;right:-14px;width:40px;height:40px;border-radius:50%;background:var(--or);color:#1a0e00;border:none;cursor:pointer;font-size:18px}
.modal-inner{display:flex;flex-direction:column;align-items:center;gap:14px}
.modal-dl{background:var(--or);color:#1a0e00;font-weight:800;text-decoration:none;padding:12px 22px;border-radius:12px;display:inline-flex;align-items:center;gap:8px;transition:transform .15s,background-color .15s}
.modal-dl:hover{background:var(--or2);transform:translateY(-2px)}
.app-avatar{width:42px;height:42px;border-radius:11px;object-fit:cover;display:block;margin:0 auto}
.appitem-avatar{width:26px;height:26px;border-radius:7px;object-fit:cover;vertical-align:middle;margin-right:6px}
.addapp-form{display:flex;flex-direction:column;gap:10px}
.addapp-form .btn-main{margin-top:4px;width:auto;align-self:flex-start}
.avatar-pick{display:flex;align-items:center;gap:10px;background:var(--bg);border:1px dashed var(--line);border-radius:10px;padding:13px 14px;cursor:pointer;color:var(--mut);font-size:14px;transition:border-color .15s}
.avatar-pick:hover{border-color:var(--or)}
.avatar-pick i{color:var(--or)}
/* login */
.login-body{display:grid;place-items:center;min-height:100vh}
.login-card{position:relative;z-index:1;width:min(380px,92vw);background:linear-gradient(180deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:24px;padding:38px 30px;text-align:center;animation:rise .5s both}
.login-card .logo{width:74px;height:74px;border-radius:20px;background:rgba(255,122,0,.12);border:1px solid var(--or);display:grid;place-items:center;margin:0 auto 18px;font-size:30px;color:var(--or)}
.login-card h1{font-size:28px;font-weight:800}.login-card h1 span{color:var(--or)}
.login-card .sub{color:var(--mut);margin:6px 0 22px;font-size:14px}
.field{display:flex;align-items:center;gap:10px;background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:0 14px;margin-bottom:14px}
.field i{color:var(--or)}
.field input{flex:1;background:none;border:none;outline:none;color:var(--txt);padding:15px 0;font-size:15px;font-family:inherit}
.btn-main{width:100%;background:var(--or);color:#1a0e00;border:none;font-weight:800;font-size:15px;font-family:inherit;padding:15px;border-radius:12px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:9px;transition:transform .15s,background-color .15s}
.btn-main:hover{background:var(--or2);transform:translateY(-2px)}
.hint{color:var(--mut);font-size:12px;margin-top:16px}
.error{background:rgba(255,77,77,.12);border:1px solid var(--red);color:#ffb3b3;padding:11px;border-radius:10px;margin-bottom:16px;font-size:14px}
/* settings */
.settings{max-width:680px}
.card{background:linear-gradient(180deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:18px;padding:24px;margin-bottom:20px;animation:rise .5s both}
.card h2{font-size:17px;margin-bottom:6px}.card h2 i{color:var(--or);margin-right:8px}
.muted{color:var(--mut);font-size:13px;margin-bottom:16px}.muted code{color:var(--or2)}
.card label{display:block;font-size:12px;color:var(--mut);margin:12px 0 6px;text-transform:uppercase;letter-spacing:1px}
.card input{width:100%;background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:13px 14px;color:var(--txt);font-family:inherit;font-size:15px;outline:none}
.card input:focus{border-color:var(--or)}
.card .btn-main{margin-top:18px;width:auto;padding:12px 22px}
.row{display:flex;gap:10px;align-items:center}
.row input{flex:1}.row .btn-main{margin-top:0;padding:13px 18px}
.applist{margin-top:18px;display:flex;flex-direction:column;gap:10px}
.appitem{display:flex;align-items:center;justify-content:space-between;background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:12px 14px}
.appitem i{color:var(--or);margin-right:8px}.appitem code{color:var(--mut);font-size:12px;margin-left:8px}
.del-btn{background:rgba(255,77,77,.12);border:1px solid var(--red);color:var(--red);border-radius:8px;padding:8px 11px;cursor:pointer}
.del-btn:hover{background:var(--red);color:#fff}
.ok-banner{background:rgba(39,201,63,.12);border:1px solid var(--green);color:#aef0b8;padding:13px;border-radius:10px;margin-bottom:20px}
@keyframes rise{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
@keyframes sweep{to{transform:translateX(100%)}}
@keyframes blink{0%,100%{opacity:1}50%{opacity:0.3}}
.statusbar{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:34px;animation:rise .5s both}
.stat{flex:1;min-width:150px;background:linear-gradient(180deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:14px;padding:15px 18px;display:flex;flex-direction:column;gap:6px}
.stat .lbl{font-size:11px;color:var(--mut);text-transform:uppercase;letter-spacing:1.5px}
.stat .lbl i{color:var(--or);margin-right:7px}
.stat .val{font-size:24px;font-weight:800}
.nowplaying{display:flex;align-items:center;gap:10px;background:rgba(255,122,0,.10);border:1px solid var(--or);border-radius:12px;padding:11px 16px;margin-bottom:16px;font-weight:600;font-size:14px}
.nowplaying i{color:var(--or)}
.nowplaying{flex-direction:row;align-items:center;gap:14px}
.np-cover{width:56px;height:56px;border-radius:10px;object-fit:cover;border:1px solid var(--or);flex-shrink:0}
.np-info{flex:1;min-width:0;display:flex;flex-direction:column}
.np-head{display:flex;align-items:center;gap:10px;min-width:0}
.np-head span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.progress-row{display:flex;align-items:center;gap:10px;margin-top:10px}
.np-time{font-size:11px;color:var(--mut);font-variant-numeric:tabular-nums;min-width:34px;text-align:center}
.progress-row .bar{flex:1;height:6px;background:rgba(255,255,255,.12);border-radius:99px;overflow:hidden}
.progress-row .fill{height:100%;width:0;background:linear-gradient(90deg,var(--or),var(--or2));border-radius:99px;transition:width .8s linear}
.vol-row{display:flex;align-items:center;gap:14px;background:linear-gradient(180deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:12px;padding:14px 18px;margin-bottom:16px}
.vol-row i{color:var(--or);font-size:16px}
.vol-val{min-width:46px;text-align:right;font-weight:800;color:var(--or2);font-variant-numeric:tabular-nums}
#vol-slider{flex:1;-webkit-appearance:none;appearance:none;height:6px;border-radius:99px;background:rgba(255,255,255,.14);outline:none;cursor:pointer}
#vol-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:20px;height:20px;border-radius:50%;background:var(--or);border:3px solid #1a0e00;box-shadow:0 0 0 1px var(--or);transition:transform .12s}
#vol-slider::-webkit-slider-thumb:hover{transform:scale(1.15)}
#vol-slider::-moz-range-thumb{width:18px;height:18px;border:none;border-radius:50%;background:var(--or);cursor:pointer}
.confirm-box{position:relative;z-index:1;width:min(380px,92vw);background:linear-gradient(180deg,var(--panel),var(--panel2));border:1px solid var(--line);border-radius:20px;padding:30px 26px;text-align:center;animation:rise .3s both}
.confirm-ic{width:64px;height:64px;border-radius:50%;background:rgba(255,77,77,.12);border:1px solid var(--red);display:grid;place-items:center;margin:0 auto 16px;font-size:26px;color:var(--red)}
.confirm-box p{font-size:16px;font-weight:600;margin-bottom:22px}
.confirm-actions{display:flex;gap:12px}
.btn-ghost{flex:1;background:var(--panel);border:1px solid var(--line);color:var(--txt);font-weight:700;font-family:inherit;padding:13px;border-radius:12px;cursor:pointer;transition:border-color .15s}
.btn-ghost:hover{border-color:var(--txt)}
.btn-danger{flex:1;background:var(--red);border:none;color:#fff;font-weight:800;font-family:inherit;padding:13px;border-radius:12px;cursor:pointer;transition:transform .15s,opacity .15s}
.btn-danger:hover{transform:translateY(-2px);opacity:.92}
.install-pulse{border-color:var(--or);color:var(--or);animation:ipulse 2s infinite}
@keyframes ipulse{0%,100%{box-shadow:0 0 0 0 rgba(255,122,0,.45)}50%{box-shadow:0 0 0 7px rgba(255,122,0,0)}}
.install-box{text-align:left}
.install-ic{background:rgba(255,122,0,.12);border-color:var(--or);color:var(--or)}
.install-steps{display:flex;flex-direction:column;gap:14px;margin:18px 0 6px}
.install-steps .step{background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:13px 15px}
.install-steps .step b{display:block;margin-bottom:5px;color:var(--or2)}
.install-steps .step b i{margin-right:7px}
.install-steps .step span{font-size:13.5px;color:var(--txt);font-weight:400;line-height:1.5}
"""

TILE_MACRO = """
{% macro tile(name, icon, label, color='orange', confirm='') %}
<div class="tile {{ color }}" data-testid="action-{{ name }}"{% if confirm %} data-confirm="{{ confirm }}"{% endif %} onclick="onTile(this, '{{ name }}')">
  <div class="ic"><i class="{{ icon }}"></i></div>
  <div class="lb">{{ label }}</div>
</div>
{% endmacro %}
{% macro apptile(a, custom=false) %}
<div class="tile" data-testid="app-{{ a.id }}" onclick="openApp('{{ a.id }}', this)">
  <div class="ic">
    {% if a.avatar %}<img src="{{ a.avatar }}" class="app-avatar" alt="">{% else %}<i class="{{ a.icon if a.icon else 'fa-solid fa-cube' }}"></i>{% endif %}
  </div>
  <div class="lb">{{ a.name }}</div>
</div>
{% endmacro %}
"""


# ------------------------------------------------------------------ routes
@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        ip = _client_ip()
        wait = check_lockout(ip)
        if wait:
            error = "Prea multe încercări. Reîncearcă peste %d secunde." % wait
        elif verify_password(request.form.get("password", ""), CONFIG.get("password_hash")):
            clear_failures(ip)
            session["auth"] = True
            return redirect(url_for("home"))
        else:
            left = register_failure(ip)
            if left and left > 0:
                error = "Parolă greșită. Mai ai %d încercări." % left
            else:
                error = "Prea multe încercări. Cont blocat 15 minute."
    return render_template_string(LOGIN_HTML, css=CSS, error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def home():
    tpl = TILE_MACRO + DASH_HTML
    return render_template_string(
        tpl, css=CSS, is_windows=IS_WINDOWS,
        builtin_apps=BUILTIN_APPS, custom_apps=CONFIG.get("custom_apps", []),
        device_name=CONFIG.get("device_name", "PC-ul meu"),
        base_url=url_for("home"),
    )


@app.route("/action/<name>", methods=["POST"])
@login_required
def action(name):
    if name not in ACTIONS:
        return jsonify(ok=False, message="Acțiune necunoscută"), 404
    label, fn = ACTIONS[name]
    ok, msg = fn()
    return jsonify(ok=ok, message="%s: %s" % (label, msg))


@app.route("/app/open/<app_id>", methods=["POST"])
@login_required
def open_app(app_id):
    a = find_app(app_id)
    if not a:
        return jsonify(ok=False, message="Aplicație inexistentă"), 404
    ok, msg = run_cmd(a["command"], shell=True)
    return jsonify(ok=ok, message="%s: %s" % (a["name"], msg))


@app.route("/app/open_all", methods=["POST"])
@login_required
def open_all():
    apps = BUILTIN_APPS + CONFIG.get("custom_apps", [])
    count = 0
    for a in apps:
        ok, _ = run_cmd(a["command"], shell=True)
        if ok:
            count += 1
        time.sleep(0.05)
    return jsonify(ok=True, message="Am deschis %d aplicații" % count)


@app.route("/volume", methods=["POST"])
@login_required
def set_volume():
    raw = request.form.get("value")
    if raw is None and request.is_json:
        raw = (request.get_json(silent=True) or {}).get("value")
    try:
        val = int(raw)
    except (TypeError, ValueError):
        return jsonify(ok=False, message="Valoare invalidă"), 400
    ok, msg = apply_volume(val)
    return jsonify(ok=ok, message=msg, volume=max(0, min(100, val)))


@app.route("/status")
@login_required
def status_info():
    val = _CPU_USAGE["val"]
    cpu = round(val) if val is not None else None
    ram = round(psutil.virtual_memory().percent) if psutil else None
    return jsonify(cpu=cpu, ram=ram, volume=get_volume_percent(),
                   now_playing=get_now_playing(), windows=IS_WINDOWS)


SW_JS = """
self.addEventListener('install', (e) => { self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', (e) => { /* network passthrough */ });
"""


@app.route("/manifest.webmanifest")
def manifest():
    home = url_for("home")
    data = {
        "name": "Remote Control PC",
        "short_name": "Remote PC",
        "description": "Controlează-ți PC-ul de la distanță",
        "start_url": home,
        "scope": home,
        "display": "standalone",
        "orientation": "portrait",
        "background_color": "#0a0a0a",
        "theme_color": "#ff7a00",
        "icons": [
            {"src": url_for("icon_192"), "sizes": "192x192", "type": "image/png", "purpose": "any"},
            {"src": url_for("icon_512"), "sizes": "512x512", "type": "image/png", "purpose": "any"},
            {"src": url_for("icon_512"), "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
        ],
    }
    return Response(json.dumps(data), mimetype="application/manifest+json")


@app.route("/sw.js")
def service_worker():
    return Response(SW_JS, mimetype="application/javascript")


@app.route("/icon-192.png")
def icon_192():
    return send_file(os.path.join(BASE_DIR, "icon-192.png"), mimetype="image/png")


@app.route("/icon-512.png")
def icon_512():
    return send_file(os.path.join(BASE_DIR, "icon-512.png"), mimetype="image/png")


@app.route("/icon-180.png")
def icon_apple():
    return send_file(os.path.join(BASE_DIR, "icon-180.png"), mimetype="image/png")


@app.route("/now_playing/cover")
@login_required
def now_playing_cover():
    if not LAST_COVER["data"]:
        return ("", 404)
    return Response(LAST_COVER["data"], mimetype=LAST_COVER.get("mime") or "image/jpeg")


@app.route("/screenshot/view")
@login_required
def screenshot_view():
    if not os.path.exists(SHOT_PATH):
        ok, _ = act_screenshot()
    return send_file(SHOT_PATH, mimetype="image/png")


@app.route("/screen/stream")
@login_required
def screen_stream():
    """Live stream MJPEG al ecranului (~6 fps). Compatibil Android/Chrome."""
    return Response(
        _generate_screen_stream(),
        mimetype="multipart/x-mixed-replace; boundary=frame",
    )


@app.route("/screen/frame")
@login_required
def screen_frame():
    """Un singur frame JPEG — folosit de polling pe iPhone/Safari."""
    frame = _capture_frame_jpeg(quality=50)
    if frame is None:
        # Fallback: screenshot salvat
        ok, _ = act_screenshot()
        if os.path.exists(SHOT_PATH):
            return send_file(SHOT_PATH, mimetype="image/png")
        return ("", 503)
    return Response(frame, mimetype="image/jpeg",
                    headers={"Cache-Control": "no-store"})


@app.route("/processes")
@login_required
def processes():
    """Lista proceselor cu ferestre vizibile."""
    return jsonify(apps=get_running_apps())


@app.route("/processes/kill", methods=["POST"])
@login_required
def kill_proc():
    """Inchide un proces dupa PID."""
    data = request.get_json(silent=True) or {}
    pid = data.get("pid")
    if pid is None:
        try:
            pid = int(request.form.get("pid", ""))
        except (TypeError, ValueError):
            return jsonify(ok=False, message="PID invalid"), 400
    try:
        pid = int(pid)
    except (TypeError, ValueError):
        return jsonify(ok=False, message="PID invalid"), 400
    ok, msg = kill_process(pid)
    return jsonify(ok=ok, message=msg)


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    msg = None
    if request.method == "POST":
        form = request.form.get("form")
        if form == "wol":
            CONFIG["mac"] = request.form.get("mac", "").strip()
            CONFIG["broadcast"] = request.form.get("broadcast", "").strip() or "255.255.255.255"
            save_config(CONFIG)
            msg = "Setări Wake-on-LAN salvate."
        elif form == "password":
            new = request.form.get("password", "").strip()
            if new:
                CONFIG["password_hash"] = hash_password(new)
                save_config(CONFIG)
                msg = "Parola a fost schimbată."
        elif form == "device":
            name = request.form.get("device_name", "").strip()
            CONFIG["device_name"] = name or "PC-ul meu"
            save_config(CONFIG)
            msg = "Numele dispozitivului a fost salvat."
    return render_template_string(SETTINGS_HTML, css=CSS, cfg=CONFIG, msg=msg)


def _process_avatar(file_storage):
    try:
        import io
        from PIL import Image
        img = Image.open(file_storage.stream).convert("RGBA")
        img.thumbnail((128, 128))
        b = io.BytesIO()
        img.save(b, "PNG")
        return "data:image/png;base64," + base64.b64encode(b.getvalue()).decode()
    except Exception:
        return None


@app.route("/apps/add", methods=["POST"])
@login_required
def add_app():
    name = request.form.get("name", "").strip()
    command = request.form.get("command", "").strip()
    if name and command:
        entry = {
            "id": "c_" + secrets.token_hex(4),
            "name": name,
            "command": command,
            "icon": "fa-solid fa-cube",
        }
        file = request.files.get("avatar")
        if file and file.filename:
            avatar = _process_avatar(file)
            if avatar:
                entry["avatar"] = avatar
        CONFIG.setdefault("custom_apps", []).append(entry)
        save_config(CONFIG)
    return redirect(url_for("settings"))


@app.route("/apps/delete", methods=["POST"])
@login_required
def delete_app():
    app_id = request.form.get("id", "")
    CONFIG["custom_apps"] = [a for a in CONFIG.get("custom_apps", []) if a["id"] != app_id]
    save_config(CONFIG)
    return redirect(url_for("settings"))


if __name__ == "__main__":
    use_https = bool(os.environ.get("REMOTE_PC_HTTPS")) or CONFIG.get("use_https")
    ssl_context = "adhoc" if use_https else None
    scheme = "https" if use_https else "http"

    # Detecteaza IP local pentru afisare
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except Exception:
        local_ip = "localhost"

    PORT = int(os.environ.get("REMOTE_PC_PORT", 5000))

    print("=" * 54)
    print("  Remote Control PC  -  pornit!")
    print("  Local:    %s://localhost:%d" % (scheme, PORT))
    print("  Retea:    %s://%s:%d" % (scheme, local_ip, PORT))
    if use_https:
        print("  HTTPS activat (certificat self-signed)")
    print("  Parola implicita: 1234  (schimb-o din Setari)")
    print("=" * 54)

    try:
        app.run(host="0.0.0.0", port=PORT, debug=False, ssl_context=ssl_context)
    except OSError as e:
        if "Address already in use" in str(e) or "10048" in str(e):
            print("\n  EROARE: Portul %d este deja folosit!" % PORT)
            print("  Solutii:")
            print("  1. Inchide alta instanta a aplicatiei din Task Manager")
            print("  2. Ruleaza cu alt port:  set REMOTE_PC_PORT=5001 && python app.py")
            input("\n  Apasa Enter pentru a iesi...")
        else:
            raise
