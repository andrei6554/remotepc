@echo off
REM Dezactiveaza pornirea automata in fundal (anuleaza setup_background.bat).
REM Ruleaza ca ADMINISTRATOR.
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [!] Ruleaza ca ADMINISTRATOR (click dreapta -^> Run as administrator).
  pause
  exit /b
)

echo Opresc si elimin serviciul ngrok...
ngrok service stop 2>nul
ngrok service uninstall 2>nul

set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if exist "%STARTUP%\RemotePC.lnk" del "%STARTUP%\RemotePC.lnk"

echo.
echo Gata! Pornirea automata in fundal a fost dezactivata.
echo (Procesele care ruleaza acum se vor opri la urmatorul restart,
echo  sau le poti opri din Task Manager: pythonw.exe / RemotePC.exe / ngrok.exe)
pause
