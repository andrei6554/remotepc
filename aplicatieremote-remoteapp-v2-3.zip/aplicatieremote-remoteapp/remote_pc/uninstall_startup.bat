@echo off
REM Elimina Remote PC din pornirea automata a Windows-ului.
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if exist "%STARTUP%\RemotePC.lnk" (
  del "%STARTUP%\RemotePC.lnk"
  echo Remote PC a fost scos din pornirea automata.
) else (
  echo Nu exista nicio pornire automata configurata.
)
pause
