# 🟠 Remote Control PC (Windows)

Controlează-ți PC-ul Windows de oriunde din lume — pornire (Wake-on-LAN), oprire,
restart, sleep, blocare, volum, mute, screenshot, Task Manager și deschiderea
aplicațiilor — totul dintr-o pagină web simplă, cu fundal negru și pictograme portocalii.

---

## 1. Ce-ți trebuie
- Windows 10/11
- Python 3.9+ (https://www.python.org/downloads/ — bifează „Add Python to PATH")

## 2. Pornire rapidă (fișier .py)
1. Copiază folderul `remote_pc` pe PC-ul Windows.
2. Deschide **Command Prompt** în acel folder și rulează:
   ```
   pip install -r requirements.txt
   python app.py
   ```
3. Pe orice dispozitiv din aceeași rețea deschide:  `http://IP-UL-PC:5000`
   (afli IP-ul cu comanda `ipconfig` → „IPv4 Address", ex: 192.168.1.105)
4. Parola implicită: **1234** (schimb-o din **Setări**).

## 3. Fă un .exe (dublu-click, fără Python)
În folder, rulează:
```
build_exe.bat
```
sau manual:
```
pip install pyinstaller
pyinstaller --onefile --noconsole --name RemotePC app.py
```
Executabilul apare în folderul `dist\RemotePC.exe`. Pune-l la **Startup** ca să
pornească odată cu Windows (apasă `Win+R`, scrie `shell:startup`, copiază acolo un shortcut).

## 4. Acces de oriunde (fără WiFi / pe date mobile)

### Varianta A — ngrok (cea mai simplă, fără setări la router)
1. Descarcă ngrok: https://ngrok.com/download și fă-ți cont gratuit.
2. Rulează aplicația (`python app.py`), apoi într-o altă fereastră:
   ```
   ngrok http 5000
   ```
3. Primești un link public de forma `https://xxxx.ngrok-free.app` — îl deschizi de pe telefon de oriunde.

### Varianta B — Port forwarding pe router
1. Intră în router (de obicei `192.168.1.1`).
2. La **Port Forwarding** redirecționează portul extern `5000` către IP-ul PC-ului, port `5000`.
3. Accesează de afară: `http://IP-UL-TĂU-PUBLIC:5000` (afli IP public pe whatismyip.com).
> Recomandare: lasă **parola** activă și folosește o parolă puternică din Setări.

## 5. Wake-on-LAN (pornirea PC-ului oprit)
Ca să poți **porni** PC-ul când e oprit:
1. În **BIOS/UEFI** activează „Wake on LAN" / „Power On by PCI-E".
2. În Windows: Device Manager → placa de rețea → Properties → Power Management →
   bifează „Allow this device to wake the computer".
3. Află adresa MAC: `ipconfig /all` → „Physical Address" a plăcii de rețea.
4. Introdu MAC-ul în pagina **Setări** a aplicației.
> Notă: pentru pornire prin internet (nu doar în rețeaua locală) ai nevoie și de un
> router care suportă „WoL over WAN" sau un dispozitiv mereu pornit care trimite pachetul.

## 4b. 📱 Instalează aplicația pe telefon (ca o aplicație adevărată)
Aplicația e un **PWA** — o poți pune pe ecranul telefonului, cu iconiță, fără bara de browser.

1. Deschide aplicația pe telefon **printr-un link HTTPS** (cel mai simplu: link-ul de la **ngrok**).
   - ⚠️ Instalarea pe telefon merge doar pe **HTTPS** (ngrok oferă automat). Pe `http://192.168...` simplu, telefonul NU permite instalarea.
   - Pe PC local (`http://localhost:5000`) merge oricum.
2. **Android (Chrome):** apasă meniul **⋮** → **„Instalează aplicația" / „Add to Home screen"**.
   (sau apasă iconița 📱 din colțul dreapta-sus al aplicației)
3. **iPhone (Safari):** apasă **„Share"** (pătrățel cu săgeată) → **„Add to Home Screen"**.
4. Gata — pe ecran apare iconița portocalie „Remote PC". O deschizi ca pe orice aplicație.

> Reține: aplicația de pe telefon e doar „telecomanda". Programul de pe PC trebuie să ruleze
> ca telefonul să poată comanda calculatorul.


## 6. Funcții disponibile
- **Status live:** CPU, Memorie (RAM) și Volum afișate în timp real (actualizare la 2.5s)
- **Melodie curentă:** titlul piesei care rulează apare deasupra butoanelor media
- **Alimentare:** Pornește (WoL), Oprește, Repornește, Sleep, Blochează, Deconectare, Oprește ecran, Anulează oprirea
  (Oprește / Repornește / Deconectare cer o **confirmare** ca să eviți apăsările accidentale)
- **Sunet & Media:** Volum +, Volum −, Mute, Play/Pauză, Anterior, Următor
- **Sistem:** Task Manager, Screenshot (vezi ecranul PC-ului în browser)
- **Aplicații:** Chrome, Edge, Notepad, Calculator, Explorer, Spotify, Terminal, Setări + „Deschide tot"
- **Aplicații personalizate:** adaugă orice program prin cale/comandă din Setări

## 6a. Pornire automată cu Windows
Ca aplicația să pornească singură la deschiderea calculatorului:
- rulează **`install_startup.bat`** (creează un shortcut în folderul Startup)
- pentru a renunța: rulează **`uninstall_startup.bat`**
> Dacă ai făcut .exe, pune `RemotePC.exe` în același folder cu scriptul înainte de a rula `install_startup.bat`.

## 6a-bis. ⭐ Fără ferestre deschise + pornire la boot (RECOMANDAT)
Vrei ca totul să meargă singur, în fundal, fără să ții nimic deschis pe PC?

### Varianta rapidă (un click)
- Dublu-click pe **`start_all.bat`** → pornește aplicația **ascuns** (fără consolă) + ngrok.
  Trebuie rulat o dată după fiecare pornire a PC-ului.

### Varianta completă (pornire automată la boot, 100% în fundal)
1. Pune `ngrok.exe` în acest folder și fă-ți un **domeniu static gratuit** pe dashboard.ngrok.com → „Domains" (ca link-ul să nu se mai schimbe).
2. **Click dreapta** pe **`setup_background.bat`** → **„Run as administrator"**.
3. Lipești authtoken-ul ngrok și (opțional) domeniul static.
4. Gata! De acum, la fiecare pornire a PC-ului:
   - aplicația pornește **ascuns** (fără fereastră),
   - ngrok pornește ca **serviciu Windows** (fără fereastră),
   - link-ul tău `https://...` merge mereu de pe telefon.
- Ca să dezactivezi: rulează **`remove_background.bat`** ca administrator.

> Notă: aplicația tot „rulează" pe PC (în fundal, invizibil) — doar că nu mai vezi nicio fereastră
> și nu mai trebuie să pornești nimic manual. PC-ul trebuie să fie pornit ca telefonul să-l comande.



## 6b. Securitate
- **Parolă criptată (hash bcrypt):** parola NU se mai salvează în text simplu. La prima
  pornire, parola veche este migrată automat în hash.
- **Protecție brute-force:** după 5 încercări greșite, accesul de pe acel IP este blocat 15 minute.
- **HTTPS (opțional):** pentru conexiune criptată când deschizi direct portul, pornește cu:
  ```
  set REMOTE_PC_HTTPS=1
  python app.py
  ```
  (folosește un certificat self-signed — browserul va cere o confirmare o singură dată).
  Notă: dacă folosești **ngrok**, ai deja HTTPS automat, nu mai e nevoie de asta.


## 7. Probleme frecvente
- *Volumul/mute nu merge* → trebuie să ruleze pe Windows real (în preview e simulat).
- *Nu pornește PC-ul* → verifică pașii Wake-on-LAN de mai sus.
- *Nu se deschide din afară* → verifică firewall-ul Windows (permite Python/RemotePC.exe).
