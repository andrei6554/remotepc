@echo off
REM Pornire rapida: aplicatia (in fundal, fara consola) + ngrok intr-un singur click.
cd /d "%~dp0"
echo Pornesc Remote PC in fundal...
start "" pythonw "%~dp0app.py"
timeout /t 2 >nul
echo Pornesc ngrok pe portul 5000...
start "ngrok" ngrok http 5000
echo.
echo Gata! In fereastra ngrok ai link-ul https://... pentru telefon.
echo (Aplicatia ruleaza ascuns - nu o vezi, dar merge.)
