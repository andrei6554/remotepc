@echo off
echo ============================================
echo   Construiesc RemotePC.exe ...
echo ============================================
pip install -r requirements.txt
pip install pyinstaller
pyinstaller --onefile --noconsole --name RemotePC --icon=icon.ico app.py
echo.
echo Gata! Executabilul este in:  dist\RemotePC.exe
pause
