@echo off
title Remote Control PC
echo Pornesc Remote Control PC...

:: Opreste orice instanta veche pe portul 5000
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr ":5000 "') do (
    taskkill /PID %%a /F >nul 2>&1
)
timeout /t 1 /nobreak >nul

:: Instaleaza dependentele daca lipsesc
echo Verific dependente...
pip install -r requirements.txt --quiet >nul 2>&1

:: Porneste aplicatia
echo Aplicatia porneste. Deschide pe telefon: http://IP-PC:5000
echo (parola implicita: 1234)
echo.
python app.py
pause
