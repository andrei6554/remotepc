@echo off
REM ============================================================
REM   Remote PC - pornire automata IN FUNDAL la boot
REM   (aplicatia ascunsa + ngrok ca serviciu Windows)
REM   ATENTIE: ruleaza acest fisier ca ADMINISTRATOR!
REM   (click dreapta -> Run as administrator)
REM ============================================================
cd /d "%~dp0"

REM --- verifica drepturi de administrator ---
net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [!] Trebuie sa rulezi ca ADMINISTRATOR.
  echo     Click dreapta pe acest fisier -^> Run as administrator.
  pause
  exit /b
)

echo.
set /p TOKEN=1) Lipeste ngrok AUTHTOKEN (de pe dashboard.ngrok.com) si apasa Enter: 
echo.
echo 2) (Optional) Domeniu STATIC ngrok ca link-ul sa NU se mai schimbe.
echo    Il creezi gratuit pe dashboard.ngrok.com la sectiunea "Domains".
set /p DOMAIN=   Scrie domeniul (ex: numele-tau.ngrok-free.app) sau lasa gol: 

REM --- scrie configul ngrok ---
if not exist "%LOCALAPPDATA%\ngrok" mkdir "%LOCALAPPDATA%\ngrok"
set "CFG=%LOCALAPPDATA%\ngrok\ngrok.yml"
> "%CFG%" echo version: "3"
>> "%CFG%" echo agent:
>> "%CFG%" echo   authtoken: %TOKEN%
>> "%CFG%" echo tunnels:
>> "%CFG%" echo   remotepc:
>> "%CFG%" echo     addr: 5000
>> "%CFG%" echo     proto: http
if not "%DOMAIN%"=="" >> "%CFG%" echo     domain: %DOMAIN%

REM --- aplicatia porneste in fundal la boot (Startup, fara consola) ---
set "TARGET=pythonw"
set "ARGS=%~dp0app.py"
if exist "%~dp0RemotePC.exe" (
  set "TARGET=%~dp0RemotePC.exe"
  set "ARGS="
)
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
powershell -NoProfile -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%STARTUP%\RemotePC.lnk');" ^
  "$s.TargetPath='%TARGET%';" ^
  "if('%ARGS%' -ne ''){$s.Arguments='\"%ARGS%\"'};" ^
  "$s.WorkingDirectory='%~dp0';" ^
  "$s.IconLocation='%~dp0icon.ico';" ^
  "$s.WindowStyle=7;" ^
  "$s.Save()"

REM --- ngrok ca serviciu Windows (porneste la boot, fara fereastra) ---
ngrok service install --config "%CFG%"
ngrok service start

REM --- porneste aplicatia acum (sa nu astepti un restart) ---
start "" %TARGET% %ARGS%

echo.
echo ============================================================
echo  GATA! De acum, la fiecare pornire a PC-ului, totul ruleaza
echo  singur, in fundal, fara nicio fereastra deschisa.
if not "%DOMAIN%"=="" echo  Deschide pe telefon:  https://%DOMAIN%
if "%DOMAIN%"=="" echo  Link-ul il vezi pe dashboard.ngrok.com (Endpoints).
echo ============================================================
pause
