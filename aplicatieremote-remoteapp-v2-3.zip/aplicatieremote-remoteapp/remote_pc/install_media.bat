@echo off
REM Instaleaza suportul pentru titlul + coperta melodiei (optional).
REM Incearca intai "winsdk"; daca da eroare, foloseste pachetele noi "winrt".
echo Incerc sa instalez suportul pentru melodie (winsdk)...
pip install winsdk
if %errorlevel%==0 (
  echo.
  echo Gata! Reporneste aplicatia.
  pause
  exit /b
)
echo.
echo winsdk nu a mers (probabil ai Python nou). Incerc varianta winrt...
pip install winrt-runtime winrt-Windows.Media.Control winrt-Windows.Storage.Streams winrt-Windows.Foundation
echo.
if %errorlevel%==0 (
  echo Gata cu winrt! Reporneste aplicatia.
) else (
  echo Nu a mers niciuna. Nu-i grav - melodia nu va aparea, dar restul aplicatiei merge normal.
)
pause
