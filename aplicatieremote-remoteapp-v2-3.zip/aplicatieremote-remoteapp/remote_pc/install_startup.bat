@echo off
REM Adauga Remote PC la pornirea automata a Windows-ului.
setlocal
set "TARGET=%~dp0RemotePC.exe"
if not exist "%TARGET%" (
  echo Nu am gasit RemotePC.exe. Ruleaza mai intai build_exe.bat, apoi muta acest script langa exe.
  echo Alternativ, voi crea un shortcut care porneste app.py cu Python.
  set "TARGET=pythonw"
  set "ARGS=%~dp0app.py"
)
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
powershell -NoProfile -Command ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%STARTUP%\RemotePC.lnk');" ^
  "$s.TargetPath='%TARGET%';" ^
  "if('%ARGS%' -ne ''){$s.Arguments='%ARGS%'};" ^
  "$s.WorkingDirectory='%~dp0';" ^
  "$s.IconLocation='%~dp0icon.ico';" ^
  "$s.Save()"
echo.
echo Gata! Remote PC va porni automat la urmatoarea pornire a Windows-ului.
pause
