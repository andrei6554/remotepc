import { useEffect, useState, useCallback, useRef } from "react";
import "@/App.css";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const APPS = [
  { id: "chrome", name: "Chrome", icon: "fa-brands fa-chrome" },
  { id: "edge", name: "Edge", icon: "fa-brands fa-edge" },
  { id: "notepad", name: "Notepad", icon: "fa-regular fa-file-lines" },
  { id: "calc", name: "Calculator", icon: "fa-solid fa-calculator" },
  { id: "explorer", name: "Explorer", icon: "fa-regular fa-folder-open" },
  { id: "spotify", name: "Spotify", icon: "fa-brands fa-spotify" },
  { id: "cmd", name: "Terminal", icon: "fa-solid fa-terminal" },
  { id: "settings", name: "Setări", icon: "fa-solid fa-gear" },
];

const POWER = [
  { a: "shutdown", icon: "fa-solid fa-power-off", lb: "Oprește PC", color: "red", confirm: "Sigur vrei să OPREȘTI PC-ul?" },
  { a: "restart", icon: "fa-solid fa-rotate-right", lb: "Repornește", color: "amber", confirm: "Sigur vrei să REPORNEȘTI PC-ul?" },
  { a: "sleep", icon: "fa-solid fa-moon", lb: "Sleep", color: "orange" },
  { a: "lock", icon: "fa-solid fa-lock", lb: "Blochează", color: "orange" },
  { a: "logoff", icon: "fa-solid fa-right-from-bracket", lb: "Deconectare", color: "orange", confirm: "Sigur vrei să te DECONECTEZI?" },
  { a: "monitor_off", icon: "fa-solid fa-display", lb: "Oprește ecran", color: "orange" },
  { a: "abort", icon: "fa-solid fa-ban", lb: "Anulează oprirea", color: "orange" },
];

const SOUND = [
  { a: "vol_up", icon: "fa-solid fa-volume-high", lb: "Volum +" },
  { a: "vol_down", icon: "fa-solid fa-volume-low", lb: "Volum -" },
  { a: "mute", icon: "fa-solid fa-volume-xmark", lb: "Mute" },
  { a: "media_play", icon: "fa-solid fa-play", lb: "Play/Pauză", color: "green" },
  { a: "media_prev", icon: "fa-solid fa-backward-step", lb: "Anterior" },
  { a: "media_next", icon: "fa-solid fa-forward-step", lb: "Următor" },
];

function fmtTime(s) {
  s = Math.max(0, Math.floor(s || 0));
  return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
}

function Connect({ onConnected }) {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError(""); setLoading(true);
    try {
      const r = await fetch(`${API}/connect`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.trim() }),
      });
      const d = await r.json();
      if (d.ok) onConnected({ code: code.trim(), name: d.name });
      else setError(d.message || "Eroare");
    } catch { setError("Nu mă pot conecta la server."); }
    setLoading(false);
  };

  return (
    <div className="login-body">
      <form className="login-card" onSubmit={submit}>
        <div className="logo"><i className="fa-solid fa-power-off" /></div>
        <h1>Remote <span>PC</span></h1>
        <p className="sub">Introdu IPv4-ul PC-ului pe care vrei să-l controlezi</p>
        {error && <div className="error" data-testid="connect-error">{error}</div>}
        <div className="field">
          <i className="fa-solid fa-network-wired" />
          <input value={code} onChange={(e) => setCode(e.target.value)}
            placeholder="ex: 192.168.1.100"
            inputMode="decimal" data-testid="connect-code-input" required />
        </div>
        <button className="btn-main" disabled={loading} data-testid="connect-submit">
          <i className="fa-solid fa-plug" /> {loading ? "Se conectează..." : "Conectează-te"}
        </button>
        <p className="hint">IPv4-ul îl găsești în fereastra agentului pornit pe PC.</p>
      </form>
    </div>
  );
}

function Tile({ icon, lb, color, onClick, busy, avatar, removable, onRemove }) {
  return (
    <div className={`tile ${color || "orange"} ${busy ? "busy" : ""}`} onClick={onClick} data-testid={`tile-${lb}`}>
      {removable && <button className="tile-x" onClick={(e) => { e.stopPropagation(); onRemove(); }} data-testid="tile-remove"><i className="fa-solid fa-xmark" /></button>}
      <div className="ic">{avatar ? <img src={avatar} className="app-avatar" alt="" /> : <i className={icon} />}</div>
      <div className="lb">{lb}</div>
    </div>
  );
}

function Dashboard({ creds, onDisconnect }) {
  const [state, setState] = useState({ online: false });
  const [toast, setToast] = useState(null);
  const [confirm, setConfirm] = useState(null);
  const [shot, setShot] = useState(null);
  const [editApps, setEditApps] = useState(false);
  const [vol, setVol] = useState(50);
  const dragging = useRef(false);
  const toastTimer = useRef(null);

  const hiddenKey = `hidden_${creds.code}`;
  const [hidden, setHidden] = useState(() => {
    try { return JSON.parse(localStorage.getItem(hiddenKey) || "[]"); } catch { return []; }
  });
  const saveHidden = (h) => { setHidden(h); localStorage.setItem(hiddenKey, JSON.stringify(h)); };

  const showToast = (msg, ok) => {
    setToast({ msg, ok });
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3000);
  };

  const refresh = useCallback(async () => {
    try {
      const r = await fetch(`${API}/state?code=${encodeURIComponent(creds.code)}`);
      const d = await r.json();
      setState(d);
      if (!dragging.current && d.volume != null) setVol(d.volume);
    } catch { setState({ online: false }); }
  }, [creds]);

  useEffect(() => { refresh(); const t = setInterval(refresh, 2500); return () => clearInterval(t); }, [refresh]);

  const cmd = async (action, value) => {
    try {
      const r = await fetch(`${API}/command`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...creds, action, value }),
      });
      const d = await r.json();
      showToast(d.message, d.ok);
      return d;
    } catch { showToast("Eroare de conexiune", false); }
  };

  const doAction = (item) => {
    if (item.confirm) setConfirm({ text: item.confirm, action: item.a });
    else cmd(item.a);
  };

  const openScreenshot = async () => {
    const d = await cmd("screenshot");
    if (d && d.ok) setShot(`${API}/screenshot?code=${encodeURIComponent(creds.code)}&t=${Date.now()}`);
  };

  const np = state.now_playing;
  const coverUrl = state.has_cover
    ? `${API}/cover?code=${encodeURIComponent(creds.code)}&k=${encodeURIComponent((np && np.title) || "")}`
    : null;
  const visibleApps = APPS.filter((a) => !hidden.includes(a.id));

  return (
    <div>
      <header className="topbar">
        <div className="brand"><i className="fa-solid fa-power-off" /> {state.name || creds.name || "PC-ul meu"}</div>
        <div className={`status ${state.online ? "" : "off"}`} data-testid="online-status">
          <span className={`dot ${state.online ? "live" : "offline"}`} />
          {state.online ? "Conectat" : "PC oprit / deconectat"}
        </div>
        <div className="actions">
          <button className="icon-btn" onClick={() => setEditApps(!editApps)} title="Editează aplicațiile" data-testid="toggle-edit-apps"><i className="fa-solid fa-pen" /></button>
          <button className="icon-btn" onClick={onDisconnect} title="Ieși" data-testid="disconnect-btn"><i className="fa-solid fa-arrow-right-from-bracket" /></button>
        </div>
      </header>

      <main className="wrap">
        <section className="statusbar">
          <div className="stat"><span className="lbl"><i className="fa-solid fa-microchip" /> CPU</span><span className="val" data-testid="stat-cpu">{state.cpu == null ? "—" : state.cpu + "%"}</span></div>
          <div className="stat"><span className="lbl"><i className="fa-solid fa-memory" /> Memorie</span><span className="val" data-testid="stat-ram">{state.ram == null ? "—" : state.ram + "%"}</span></div>
          <div className="stat"><span className="lbl"><i className="fa-solid fa-volume-high" /> Volum</span><span className="val" data-testid="stat-vol">{state.volume == null ? "—" : state.volume + "%"}</span></div>
        </section>

        <section className="group">
          <h2><i className="fa-solid fa-plug-circle-bolt" /> Alimentare</h2>
          <div className="grid">{POWER.map((p) => <Tile key={p.a} {...p} onClick={() => doAction(p)} />)}</div>
        </section>

        <section className="group">
          <h2><i className="fa-solid fa-volume-high" /> Sunet & Media</h2>
          {np && np.title && (
            <div className="nowplaying" data-testid="now-playing">
              {coverUrl && <img src={coverUrl} className="np-cover" alt="" />}
              <div className="np-info">
                <div className="np-head"><i className="fa-solid fa-music" /> <span>{np.title}{np.artist ? " — " + np.artist : ""}</span></div>
                {np.duration > 0 && (
                  <div className="progress-row">
                    <span className="np-time">{fmtTime(np.position)}</span>
                    <div className="bar"><div className="fill" style={{ width: Math.min(100, (np.position / np.duration) * 100) + "%" }} /></div>
                    <span className="np-time">{fmtTime(np.duration)}</span>
                  </div>
                )}
              </div>
            </div>
          )}
          <div className="vol-row">
            <i className="fa-solid fa-volume-low" />
            <input type="range" min="0" max="100" value={vol} data-testid="volume-slider"
              onChange={(e) => { dragging.current = true; setVol(+e.target.value); }}
              onMouseUp={(e) => { cmd("set_volume", +e.target.value); setTimeout(() => (dragging.current = false), 700); }}
              onTouchEnd={(e) => { cmd("set_volume", +e.target.value); setTimeout(() => (dragging.current = false), 700); }}
              onKeyUp={(e) => { cmd("set_volume", +e.target.value); setTimeout(() => (dragging.current = false), 700); }}
              onBlur={(e) => { dragging.current = false; }} />
            <span className="vol-val">{vol}%</span>
          </div>
          <div className="grid">{SOUND.map((s) => <Tile key={s.a} {...s} onClick={() => cmd(s.a)} />)}</div>
        </section>

        <section className="group">
          <h2><i className="fa-solid fa-screwdriver-wrench" /> Sistem</h2>
          <div className="grid">
            <Tile a="taskmgr" icon="fa-solid fa-list-check" lb="Task Manager" onClick={() => cmd("taskmgr")} />
            <Tile a="screenshot" icon="fa-solid fa-camera" lb="Screenshot" onClick={openScreenshot} />
          </div>
        </section>

        <section className="group">
          <div className="group-head">
            <h2><i className="fa-solid fa-grip" /> Aplicații {editApps && <small className="edit-hint">(apasă × ca să ascunzi)</small>}</h2>
            <button className="mini-btn" onClick={() => cmd("open_all")} data-testid="open-all"><i className="fa-solid fa-layer-group" /> Deschide tot</button>
          </div>
          <div className="grid">
            {visibleApps.map((a) => (
              <Tile key={a.id} icon={a.icon} lb={a.name} onClick={() => editApps ? null : cmd("open:" + a.id)}
                removable={editApps} onRemove={() => saveHidden([...hidden, a.id])} />
            ))}
          </div>
          {editApps && hidden.length > 0 && (
            <button className="reset-apps" onClick={() => saveHidden([])} data-testid="reset-apps">
              <i className="fa-solid fa-rotate-left" /> Arată din nou aplicațiile ascunse ({hidden.length})
            </button>
          )}
        </section>
      </main>

      {confirm && (
        <div className="modal open" data-testid="confirm-modal">
          <div className="confirm-box">
            <div className="confirm-ic"><i className="fa-solid fa-triangle-exclamation" /></div>
            <p>{confirm.text}</p>
            <div className="confirm-actions">
              <button className="btn-ghost" onClick={() => setConfirm(null)} data-testid="confirm-cancel">Nu, anulează</button>
              <button className="btn-danger" onClick={() => { cmd(confirm.action); setConfirm(null); }} data-testid="confirm-ok">Da, continuă</button>
            </div>
          </div>
        </div>
      )}

      {shot && (
        <div className="modal open" data-testid="screenshot-modal" onClick={() => setShot(null)}>
          <div className="modal-inner" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setShot(null)}><i className="fa-solid fa-xmark" /></button>
            <img src={shot} alt="screenshot" />
            <a className="modal-dl" href={shot} download="screenshot.png" data-testid="screenshot-download"><i className="fa-solid fa-download" /> Salvează poza</a>
          </div>
        </div>
      )}

      {toast && <div className={`toast show ${toast.ok ? "ok" : "err"}`} data-testid="toast">{toast.msg}</div>}
    </div>
  );
}

function App() {
  const [creds, setCreds] = useState(() => {
    try { return JSON.parse(localStorage.getItem("creds") || "null"); } catch { return null; }
  });
  const onConnected = (c) => { localStorage.setItem("creds", JSON.stringify(c)); setCreds(c); };
  const onDisconnect = () => { localStorage.removeItem("creds"); setCreds(null); };

  return creds ? <Dashboard creds={creds} onDisconnect={onDisconnect} /> : <Connect onConnected={onConnected} />;
}

export default App;
