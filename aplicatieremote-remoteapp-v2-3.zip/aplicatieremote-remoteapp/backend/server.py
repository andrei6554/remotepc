"""
Remote Control PC - SERVER CENTRAL (model TeamViewer).

- Agentii (programul mic de pe PC-urile prietenilor) se conecteaza prin WebSocket
  la  /api/ws/agent  si se inregistreaza cu un COD + parola (hash bcrypt).
- Site-ul (browserul) trimite comenzi prin REST la /api/command; serverul le
  releaza catre agentul potrivit si asteapta raspunsul.

Nu e nevoie de IP, port forwarding sau ngrok: agentul se conecteaza singur "afara"
catre acest server.
"""
import os
import asyncio
import base64
from uuid import uuid4
from typing import Optional, Dict, Any

import bcrypt
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import Response
from pydantic import BaseModel
from starlette.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# code -> agent record
AGENTS: Dict[str, Dict[str, Any]] = {}
# request id -> future waiting for the agent's reply
PENDING: Dict[str, asyncio.Future] = {}


def verify_password(plain: str, hashed: str) -> bool:
    if not hashed:
        return False
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def _auth(code: str, password: str) -> Optional[Dict[str, Any]]:
    agent = AGENTS.get(code)
    if agent and verify_password(password, agent["password_hash"]):
        return agent
    return None


# ----------------------------------------------------------------- agent WS
@app.websocket("/api/ws/agent")
async def agent_ws(ws: WebSocket):
    await ws.accept()
    code = None
    try:
        reg = await ws.receive_json()
        if reg.get("type") != "register":
            await ws.close()
            return
        code = str(reg.get("code"))
        AGENTS[code] = {
            "ws": ws,
            "password_hash": reg.get("password_hash", ""),
            "name": reg.get("name", "PC"),
            "platform": reg.get("platform", ""),
            "status": {},
            "cover": None,
            "cover_mime": "image/png",
            "screenshot": None,
        }
        await ws.send_json({"type": "registered", "code": code})

        while True:
            msg = await ws.receive_json()
            t = msg.get("type")
            if t == "status":
                if code in AGENTS:
                    AGENTS[code]["status"] = msg.get("data", {})
            elif t == "cover":
                if code in AGENTS and msg.get("b64"):
                    AGENTS[code]["cover"] = base64.b64decode(msg["b64"])
                    AGENTS[code]["cover_mime"] = msg.get("mime", "image/png")
            elif t == "screenshot":
                if code in AGENTS and msg.get("b64"):
                    AGENTS[code]["screenshot"] = base64.b64decode(msg["b64"])
            elif t == "result":
                fut = PENDING.get(msg.get("id"))
                if fut and not fut.done():
                    fut.set_result({"ok": msg.get("ok", False),
                                    "message": msg.get("message", "")})
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        if code and AGENTS.get(code, {}).get("ws") is ws:
            AGENTS.pop(code, None)


# ----------------------------------------------------------------- web REST
class ConnectIn(BaseModel):
    code: str
    password: str


class CommandIn(BaseModel):
    code: str
    password: str
    action: str
    value: Optional[int] = None


@app.post("/api/connect")
async def connect(body: ConnectIn):
    agent = _auth(body.code, body.password)
    if not agent:
        if body.code not in AGENTS:
            return {"ok": False, "message": "Cod inexistent sau PC-ul nu este pornit / conectat."}
        return {"ok": False, "message": "Parolă greșită."}
    return {"ok": True, "name": agent["name"], "platform": agent["platform"]}


@app.post("/api/command")
async def command(body: CommandIn):
    agent = _auth(body.code, body.password)
    if not agent:
        return {"ok": False, "message": "Cod sau parolă greșite, ori PC deconectat."}
    rid = uuid4().hex
    fut = asyncio.get_event_loop().create_future()
    PENDING[rid] = fut
    try:
        await agent["ws"].send_json({"type": "command", "id": rid,
                                     "action": body.action, "value": body.value})
        return await asyncio.wait_for(fut, timeout=12)
    except asyncio.TimeoutError:
        return {"ok": False, "message": "PC-ul nu a răspuns la timp."}
    except Exception:
        return {"ok": False, "message": "PC-ul s-a deconectat."}
    finally:
        PENDING.pop(rid, None)


@app.get("/api/state")
async def state(code: str, password: str):
    agent = _auth(code, password)
    if not agent:
        return {"online": False}
    st = dict(agent.get("status") or {})
    st["online"] = True
    st["name"] = agent["name"]
    st["has_cover"] = agent.get("cover") is not None
    return st


@app.get("/api/cover")
async def cover(code: str, password: str):
    agent = _auth(code, password)
    if not agent or not agent.get("cover"):
        return Response(status_code=404)
    return Response(agent["cover"], media_type=agent.get("cover_mime", "image/png"))


@app.get("/api/screenshot")
async def screenshot(code: str, password: str):
    agent = _auth(code, password)
    if not agent or not agent.get("screenshot"):
        return Response(status_code=404)
    return Response(agent["screenshot"], media_type="image/png")


@app.get("/api/health")
async def health():
    return {"ok": True, "agents_online": len(AGENTS)}
