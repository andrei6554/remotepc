# Cum publici pe Render + cum folosesti agentul

## PASUL 1 — Publici serverul pe Render (o singura data)

1. Mergi pe https://render.com si faci cont gratuit
2. New → Web Service → Connect a repository (GitHub)
3. Urci proiectul pe GitHub (sau dai "paste public repo URL")
4. Render detecteaza automat `render.yaml`
5. Dai Deploy — in 2-3 minute ai un link de genul:
   `https://remotepc-server.onrender.com`

## PASUL 2 — Configurezi agentul cu linkul serverului

Deschide `agent/agent_config.json` si pune linkul tau:
```json
{
  "server": "https://remotepc-server.onrender.com",
  "name": "PC-ul meu"
}
```

## PASUL 3 — Trimiti agentul prietenilor

- Builduieste EXE: ruleaza `agent/build_agent.bat`
- Trimite `RemoteAgent.exe` prietenului
- El il porneste, vede in consola IPv4-ul lui local
- Tu intri pe site, introduci IPv4-ul lui, esti conectat

## CUM FUNCTIONEAZA

```
Prietenul porneste RemoteAgent.exe
  └── agentul se conecteaza la serverul tau de pe Render
      └── afiseaza: "IPv4: 192.168.1.45"

Tu pe telefon deschizi site-ul
  └── introduci: 192.168.1.45
      └── esti conectat direct la PC-ul lui
```

## NOTA despre Render gratuit

Pe planul gratuit, serverul "adoarme" dupa 15 minute de inactivitate.
Agentul se reconecteaza automat cand serverul se trezeste (5-30 secunde).
